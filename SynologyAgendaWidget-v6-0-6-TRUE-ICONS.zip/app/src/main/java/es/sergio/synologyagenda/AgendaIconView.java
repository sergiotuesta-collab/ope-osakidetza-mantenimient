package es.sergio.synologyagenda;
import android.content.*;import android.graphics.*;import android.view.*;
public class AgendaIconView extends View{
 public static final int HOME=1,MAIL=2,REFRESH=3,SETTINGS=4,CALENDAR=5,SLIDERS=6,LAYERS=7,FOLDER=8,DOTS=9;
 int type; Paint p=new Paint(1); int color=Color.WHITE; float sw;
 public AgendaIconView(Context c,int type,int color){super(c);this.type=type;this.color=color;sw=getResources().getDisplayMetrics().density*1.8f;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sw);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setColor(color);}
 public void setIconColor(int c){color=c;invalidate();}
 protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2,s=Math.min(w,h)*.27f;p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sw);
  if(type==HOME){Path q=new Path();q.moveTo(cx-s,cy);q.lineTo(cx,cy-s*.85f);q.lineTo(cx+s,cy);q.moveTo(cx-s*.72f,cy-.05f*s);q.lineTo(cx-s*.72f,cy+s*.78f);q.lineTo(cx+s*.72f,cy+s*.78f);q.lineTo(cx+s*.72f,cy-.05f*s);c.drawPath(q,p);}
  else if(type==MAIL){RectF r=new RectF(cx-s,cy-s*.62f,cx+s,cy+s*.62f);c.drawRoundRect(r,s*.08f,s*.08f,p);c.drawLine(cx-s,cy-s*.52f,cx,cy+s*.12f,p);c.drawLine(cx+s,cy-s*.52f,cx,cy+s*.12f,p);}
  else if(type==REFRESH){RectF r=new RectF(cx-s*.8f,cy-s*.8f,cx+s*.8f,cy+s*.8f);c.drawArc(r,-65,285,false,p);Path q=new Path();q.moveTo(cx+s*.78f,cy-s*.55f);q.lineTo(cx+s*.9f,cy-s*.05f);q.lineTo(cx+s*.4f,cy-s*.15f);c.drawPath(q,p);}
  else if(type==SETTINGS){c.drawCircle(cx,cy,s*.34f,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x1=cx+(float)Math.cos(a)*s*.62f,y1=cy+(float)Math.sin(a)*s*.62f,x2=cx+(float)Math.cos(a)*s*.92f,y2=cy+(float)Math.sin(a)*s*.92f;c.drawLine(x1,y1,x2,y2,p);}c.drawCircle(cx,cy,s*.9f,p);}
  else if(type==CALENDAR){RectF r=new RectF(cx-s,cy-s*.78f,cx+s,cy+s*.82f);c.drawRoundRect(r,s*.12f,s*.12f,p);c.drawLine(cx-s,cy-s*.35f,cx+s,cy-s*.35f,p);c.drawLine(cx-s*.55f,cy-s,cx-s*.55f,cy-s*.55f,p);c.drawLine(cx+s*.55f,cy-s,cx+s*.55f,cy-s*.55f,p);for(int i=-1;i<=1;i++)for(int j=0;j<2;j++)c.drawCircle(cx+i*s*.48f,cy+j*s*.42f,s*.07f,p);}
  else if(type==SLIDERS){for(int i=-1;i<=1;i++){float y=cy+i*s*.55f;c.drawLine(cx-s,y,cx+s,y,p);float x=cx+(i==0?s*.38f:(i<0?-s*.3f:s*.05f));c.drawCircle(x,y,s*.14f,p);}}
  else if(type==LAYERS){Path q=new Path();q.moveTo(cx,cy-s);q.lineTo(cx+s,cy-s*.45f);q.lineTo(cx,cy+s*.1f);q.lineTo(cx-s,cy-s*.45f);q.close();c.drawPath(q,p);for(int k=0;k<2;k++){float off=(k+1)*s*.42f;c.drawLine(cx-s,cy-s*.45f+off,cx,cy+s*.1f+off,p);c.drawLine(cx,cy+s*.1f+off,cx+s,cy-s*.45f+off,p);}}
  else if(type==FOLDER){Path q=new Path();q.moveTo(cx-s,cy-s*.55f);q.lineTo(cx-s*.25f,cy-s*.55f);q.lineTo(cx,cy-s*.25f);q.lineTo(cx+s,cy-s*.25f);q.lineTo(cx+s,cy+s*.65f);q.lineTo(cx-s,cy+s*.65f);q.close();c.drawPath(q,p);}
  else {p.setStyle(Paint.Style.FILL);for(int i=-1;i<=1;i++)c.drawCircle(cx+i*s*.6f,cy,s*.12f,p);}
 }
}
