package es.sergio.synologyagenda;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class SynologyClient {
    private final Context ctx;
    private final String base, user, password;
    private String sid, token, did;

    public SynologyClient(Context c) {
        ctx=c.getApplicationContext();
        android.content.SharedPreferences p=c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        base=normalize(p.getString("server", "https://nastuesta.fr3.quickconnect.to"));
        user=p.getString("user", "sergio");
        password=CryptoStore.get(c,"password"); did=CryptoStore.get(c,"did");
        sid=p.getString("sid", null); token=p.getString("token", null);
    }
    private static String normalize(String s){ s=s==null?"":s.trim(); if(!s.startsWith("https://")) s="https://"+s; while(s.endsWith("/")) s=s.substring(0,s.length()-1); return s; }

    public JSONObject login(String otp, boolean firstTrust) throws Exception {
        if(password==null || password.isBlank()) throw new IOException("Falta la contraseña guardada");
        Map<String,String> q=new LinkedHashMap<>();
        q.put("api","SYNO.API.Auth"); q.put("version","6"); q.put("method","login"); q.put("account",user); q.put("passwd",password);
        q.put("session","Calendar"); q.put("format","sid"); q.put("enable_syno_token","yes");
        if(firstTrust && otp!=null && !otp.isBlank()) { q.put("otp_code",otp.trim()); q.put("enable_device_token","yes"); q.put("device_name","Agenda Synology S25"); }
        else if(did!=null && !did.isBlank()) { q.put("device_name","Agenda Synology S25"); q.put("device_id",did); }
        else if(otp!=null && !otp.isBlank()) q.put("otp_code",otp.trim());
        JSONObject r=postForm(base+"/webapi/entry.cgi", q, null);
        if(r.optBoolean("success")) {
            JSONObject d=r.getJSONObject("data"); sid=d.optString("sid",""); token=d.optString("synotoken","");
            String newDid=d.optString("did",""); if(!newDid.isBlank()){ did=newDid; CryptoStore.put(ctx,"did",did); }
            ctx.getSharedPreferences("cfg",Context.MODE_PRIVATE).edit().putString("sid",sid).putString("token",token).apply();
        }
        return r;
    }

    private void ensureAuth() throws Exception {
        if(sid==null || sid.isBlank()) {
            JSONObject lr=login(null,false); if(!lr.optBoolean("success")) throw new IOException("Necesita volver a iniciar sesión");
        }
    }

    public List<EventItem> events(long startSec, long endSec) throws Exception {
        ensureAuth();
        try { return eventsOnce(startSec,endSec); }
        catch(AuthException ex) { reloginOrThrow(); return eventsOnce(startSec,endSec); }
    }

    private List<EventItem> eventsOnce(long startSec,long endSec) throws Exception {
        Map<String,CalendarInfo> calendars=calendarMapOnce();
        Map<String,String> p=baseParams("SYNO.Cal.Event","5","list");
        p.put("start",Long.toString(startSec)); p.put("end",Long.toString(endSec)); p.put("limit","500");
        JSONObject r=call(p);
        JSONArray list=r.getJSONObject("data").optJSONArray("list"); List<EventItem> out=new ArrayList<>();
        if(list!=null) for(int i=0;i<list.length();i++){
            JSONObject e=list.getJSONObject(i); long st=e.optLong("dtstart",0);
            if(st>0) out.add(parseEvent(e,calendars));
        }
        out.sort(Comparator.comparingLong((EventItem x)->x.start).thenComparingLong(x->x.evtId)); return out;
    }

    public List<CalendarInfo> calendars() throws Exception {
        ensureAuth();
        try { return new ArrayList<>(calendarMapOnce().values()); }
        catch(AuthException ex) { reloginOrThrow(); return new ArrayList<>(calendarMapOnce().values()); }
    }

    private Map<String,CalendarInfo> calendarMapOnce() throws Exception {
        Map<String,String> p=baseParams("SYNO.Cal.Cal","5","list"); p.put("cal_type","event");
        JSONObject r=call(p); JSONArray a=r.getJSONObject("data").optJSONArray("list");
        LinkedHashMap<String,CalendarInfo> out=new LinkedHashMap<>();
        if(a!=null) for(int i=0;i<a.length();i++){
            JSONObject c=a.optJSONObject(i); if(c==null) continue;
            String id=c.optString("cal_id","").trim(); String orig=c.optString("original_cal_id",id).trim();
            String privilege=c.optString("cal_privilege","RW");
            CalendarInfo info=new CalendarInfo(id,orig,c.optString("cal_displayname","Calendario"),
                    c.optString("cal_color",""),!"RO".equalsIgnoreCase(privilege),c.optBoolean("default_calendar",false));
            if(!id.isBlank()) out.put(id,info);
        }
        return out;
    }

    public JSONObject getEvent(long evtId,String recurrenceId) throws Exception {
        ensureAuth();
        try { return getEventOnce(evtId,recurrenceId); }
        catch(AuthException ex){ reloginOrThrow(); return getEventOnce(evtId,recurrenceId); }
    }
    private JSONObject getEventOnce(long evtId,String recurrenceId)throws Exception{
        Map<String,String> p=baseParams("SYNO.Cal.Event","5","get"); p.put("evt_id",Long.toString(evtId));
        if(recurrenceId!=null&&!recurrenceId.isBlank())p.put("recurrence_id",jsonString(recurrenceId));
        JSONObject r=call(p); return r.getJSONObject("data");
    }

    public JSONObject updateEvent(long evtId,String recurrenceId,String summary,boolean allDay,long start,long end,String description,String location) throws Exception {
        if(summary==null || summary.trim().isEmpty()) throw new IllegalArgumentException("El título no puede estar vacío");
        if(end<=start) throw new IllegalArgumentException("La hora/fecha de fin debe ser posterior al inicio");

        ensureAuth();
        JSONObject current=getEvent(evtId,recurrenceId);
        resolveCalendarIds(current);
        String method=(recurrenceId!=null&&!recurrenceId.isBlank())?"subevent_set":"set";
        Map<String,String> p=buildUpdateParams(current,evtId,recurrenceId,method,summary,allDay,start,end,description,location,true);

        try {
            return call(p);
        } catch(AuthException ex) {
            reloginOrThrow();
            current=getEvent(evtId,recurrenceId);
            resolveCalendarIds(current);
            p=buildUpdateParams(current,evtId,recurrenceId,method,summary,allDay,start,end,description,location,true);
            return call(p);
        }
    }

    private void resolveCalendarIds(JSONObject current) throws Exception {
        String currentCal=current.optString("cal_id","").trim();
        String original=current.optString("original_cal_id","").trim();
        Map<String,CalendarInfo> map=calendarMapOnce();

        String resolved="";
        if(!currentCal.isBlank() && map.containsKey(currentCal)) resolved=currentCal;
        if(resolved.isBlank() && !original.isBlank() && map.containsKey(original)) resolved=original;
        if(resolved.isBlank() && !original.isBlank()) {
            for(CalendarInfo ci: map.values()) {
                if(original.equals(ci.originalCalId)) { resolved=ci.calId; break; }
            }
        }
        if(resolved.isBlank() && !currentCal.isBlank()) {
            for(CalendarInfo ci: map.values()) {
                if(currentCal.equals(ci.originalCalId)) { resolved=ci.calId; if(original.isBlank()) original=ci.originalCalId; break; }
            }
        }
        if(original.isBlank() && !resolved.isBlank()) {
            CalendarInfo ci=map.get(resolved); if(ci!=null) original=ci.originalCalId;
        }
        if(resolved.isBlank() || original.isBlank())
            throw new IOException("No se pudo identificar el calendario real del evento en Synology");
        current.put("cal_id",resolved);
        current.put("original_cal_id",original);
    }

    private Map<String,String> buildUpdateParams(JSONObject current,long evtId,String recurrenceId,String method,
                                                  String summary,boolean allDay,long start,long end,
                                                  String description,String location,boolean ignored) {
        // Keep this request deliberately aligned with Synology Calendar API v5 documentation.
        Map<String,String> p=baseParams("SYNO.Cal.Event","5",method);
        p.put("evt_id",Long.toString(evtId));
        if("subevent_set".equals(method)) p.put("recurrence_id",jsonString(recurrenceId));

        String originalCalId=current.optString("original_cal_id","").trim();
        String calId=current.optString("cal_id","").trim();
        String etag=current.optString("dav_etag","").trim();
        if(calId.isBlank() || originalCalId.isBlank() || etag.isBlank())
            throw new IllegalArgumentException("Faltan identificadores del evento devueltos por Synology");

        p.put("cal_id",jsonString(calId));
        p.put("original_cal_id",jsonString(originalCalId));
        p.put("dav_etag",jsonString(etag));
        p.put("summary",jsonString(summary.trim()));
        p.put("is_all_day",Boolean.toString(allDay));

        String tz=current.optString("tz_id","").trim();
        if(allDay) tz="";
        else if(tz.isBlank()) tz=TimeZone.getDefault().getID();
        p.put("tz_id",jsonString(tz));
        p.put("dtstart",Long.toString(start));
        p.put("dtend",Long.toString(end));
        p.put("color",jsonString(current.optString("color","")));
        p.put("notify_setting",arrayString(current,"notify_setting"));
        String safeDescription=description==null?"":description;
        // Calendar 3.x rejects an empty description in Event.set on some builds.
        p.put("description",jsonString(safeDescription));
        p.put("location_info",mergeLocation(current.optJSONObject("location_info"),location).toString());
        p.put("attachments",arrayString(current,"attachments"));

        if("set".equals(method)) {
            boolean repeat=current.optBoolean("is_repeat_evt",false);
            p.put("is_repeat_evt",Boolean.toString(repeat));
            p.put("participant",arrayString(current,"participant"));
            // Synology Calendar 3.x expects repeat_setting to be present even when the event is not recurring.
            if(repeat) {
                JSONObject rs=current.optJSONObject("repeat_setting");
                if(rs==null) throw new IllegalArgumentException("Falta la regla de repetición del evento");
                p.put("repeat_setting",rs.toString());
                String exdate=current.optString("exdate","");
                if(!exdate.isBlank()) p.put("exdate",jsonString(exdate));
            } else {
                p.put("repeat_setting","null");
            }
        }
        return p;
    }

    private static JSONObject mergeLocation(JSONObject old,String location){
        try {
            String loc=location==null?"":location.trim();
            // Calendar 3.x validates the complete location object, even when most fields are empty.
            JSONObject out=emptyLocation();
            if(old!=null) {
                Iterator<String> it=old.keys();
                while(it.hasNext()) { String k=it.next(); out.put(k, old.opt(k)); }
            }
            if(out.optJSONObject("gps")==null)
                out.put("gps",new JSONObject().put("lat",-1).put("lng",-1));
            if(!out.has("map_type")) out.put("map_type","");
            if(!out.has("place_id")) out.put("place_id","");
            out.put("name",loc);
            out.put("address",loc);
            return out;
        } catch(Exception e) { return emptyLocation(); }
    }


    public void deleteEvent(long evtId,String recurrenceId) throws Exception {
        ensureAuth();
        try { deleteEventOnce(evtId,recurrenceId); }
        catch(AuthException ex){ reloginOrThrow(); deleteEventOnce(evtId,recurrenceId); }
    }
    private void deleteEventOnce(long evtId,String recurrenceId) throws Exception {
        if(recurrenceId!=null && !recurrenceId.isBlank()) {
            JSONObject cur=getEventOnce(evtId,recurrenceId);
            String etag=cur.optString("dav_etag","").trim();
            if(etag.isBlank()) throw new IOException("Falta dav_etag para borrar esta aparición");
            Map<String,String> p=baseParams("SYNO.Cal.Event","5","set_exdate");
            p.put("evt_id",Long.toString(evtId)); p.put("dav_etag",jsonString(etag)); p.put("exdate",jsonString(recurrenceId)); call(p);
        } else {
            Map<String,String> p=baseParams("SYNO.Cal.Event","5","delete"); p.put("evt_id",Long.toString(evtId)); call(p);
        }
    }
    private static String locationText(JSONObject li){ if(li==null)return ""; String n=li.optString("name","").trim(); return n.isBlank()?li.optString("address","").trim():n; }

    private static EventItem parseEvent(JSONObject e,Map<String,CalendarInfo> calendars){
        String cid=e.optString("cal_id",""); CalendarInfo ci=calendars.get(cid);
        return new EventItem(e.optLong("evt_id",0),e.optString("recurrence_id",""),e.optString("summary","(Sin título)"),
                e.optLong("dtstart",0),e.optLong("dtend",e.optLong("dtstart",0)),e.optBoolean("is_all_day",false),
                cid,e.optString("original_cal_id",cid),e.optString("dav_etag",""),
                ci==null?"":ci.name,ci==null?"":ci.color,e.optString("description",""),locationText(e.optJSONObject("location_info")));
    }
    private static String jsonString(String value){ return JSONObject.quote(value==null?"":value); }
    private static JSONObject emptyLocation(){ try{return new JSONObject().put("address","").put("gps",new JSONObject().put("lat",-1).put("lng",-1)).put("map_type","").put("name","").put("place_id","");}catch(Exception e){return new JSONObject();} }
    private static String arrayString(JSONObject o,String k){JSONArray a=o.optJSONArray(k);return a==null?"[]":a.toString();}
    private static String objectOrNullString(JSONObject o,String k){JSONObject x=o.optJSONObject(k);return x==null?"null":x.toString();}

    private Map<String,String> baseParams(String api,String version,String method){ Map<String,String> p=new LinkedHashMap<>(); p.put("api",api);p.put("version",version);p.put("method",method); if(sid!=null&&!sid.isBlank())p.put("_sid",sid);if(token!=null&&!token.isBlank())p.put("SynoToken",token);return p; }
    private JSONObject call(Map<String,String> p)throws Exception{JSONObject r=postForm(base+"/webapi/entry.cgi",p,token);if(!r.optBoolean("success")){int code=r.optJSONObject("error")!=null?r.optJSONObject("error").optInt("code",0):0;if(code==105||code==106||code==107)throw new AuthException();throw new ApiException(code, p);}return r;}
    private void reloginOrThrow()throws Exception{JSONObject lr=login(null,false);if(!lr.optBoolean("success"))throw new IOException("Sesión caducada: abre Configuración para autenticarte de nuevo");}
    private static class AuthException extends Exception {}
    private static class ApiException extends IOException {
        final int code;
        ApiException(int c, Map<String,String> p){
            super(c==9009 ? "Synology API error 9009 · cal_id="+safe(p.get("cal_id"))+" · campos="+safeFields(p) : "Synology API error "+c);
            code=c;
        }
        private static String safe(String s){ return s==null?"":s; }
        private static String safeFields(Map<String,String> p){
            StringBuilder b=new StringBuilder();
            for(String k:p.keySet()){ if("_sid".equals(k)||"SynoToken".equals(k)) continue; if(b.length()>0)b.append(','); b.append(k); }
            return b.toString();
        }
    }
    private static String encode(Map<String,String> map) throws Exception { StringBuilder sb=new StringBuilder(); for(Map.Entry<String,String>e:map.entrySet()){ if(sb.length()>0)sb.append('&'); sb.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8")); } return sb.toString(); }
    private static JSONObject postForm(String url,Map<String,String> params,String token) throws Exception { byte[] body=encode(params).getBytes(StandardCharsets.UTF_8); HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8"); c.setRequestProperty("Accept","application/json"); if(token!=null&&!token.isBlank()) c.setRequestProperty("X-SYNO-TOKEN",token); try(OutputStream os=c.getOutputStream()){os.write(body);} return read(c); }
    private static JSONObject read(HttpURLConnection c) throws Exception { int code=c.getResponseCode(); InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream(); if(in==null) throw new IOException("HTTP "+code); String text; try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){ StringBuilder sb=new StringBuilder(); String l; while((l=br.readLine())!=null)sb.append(l); text=sb.toString(); } try{return new JSONObject(text);}catch(Exception e){throw new IOException("Respuesta no válida del NAS (HTTP "+code+")");} }
}
