package es.sergio.synologyagenda;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class HomeActivity extends Activity {
    final int bg=Color.rgb(10,12,15), panel=Color.rgb(24,28,34), panel2=Color.rgb(30,35,43), text=Color.rgb(245,247,250), muted=Color.rgb(155,165,178), accent=Color.rgb(126,174,255), green=Color.rgb(117,211,154);
    LinearLayout content; TextView syncStatus;

    @Override public void onCreate(Bundle b){super.onCreate(b); build(); render();}
    @Override protected void onResume(){super.onResume(); if(content!=null)render();}

    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setPadding(dp(18),dp(12),dp(18),0);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tt=new LinearLayout(this);tt.setOrientation(LinearLayout.VERTICAL);
        tt.addView(t(greeting(),14,false,muted));tt.addView(t("Agenda Synology",30,true,text));
        top.addView(tt,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=icon("⚙");TextView sync=icon("↻");top.addView(sync);top.addView(settings);root.addView(top);
        syncStatus=t("",12,false,muted);syncStatus.setPadding(dp(2),dp(2),0,dp(8));root.addView(syncStatus);
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,0,0,dp(26));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        settings.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));sync.setOnClickListener(v->syncAll());
    }

    void render(){
        content.removeAllViews();
        Date now=new Date(); SimpleDateFormat date=new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","ES"));
        TextView d=t(cap(date.format(now)),15,false,muted);d.setPadding(dp(2),0,0,dp(12));content.addView(d);

        List<EventItem> all=EventFilter.upcoming(this,WidgetCache.load(this));
        Calendar today=Calendar.getInstance(), tomorrow=(Calendar)today.clone();tomorrow.add(Calendar.DAY_OF_YEAR,1);
        int nToday=0,nTomorrow=0;for(EventItem e:all){Calendar ec=Calendar.getInstance();ec.setTimeInMillis(e.start*1000L);if(sameDay(today,ec))nToday++;else if(sameDay(tomorrow,ec))nTomorrow++;}
        List<MailItem> mails=MailCache.load(this);int unread=0;for(MailItem m:mails)if(m.unread)unread++;

        LinearLayout stats=new LinearLayout(this);stats.setWeightSum(3);stats.addView(stat("HOY",String.valueOf(nToday),"eventos"),new LinearLayout.LayoutParams(0,dp(108),1));stats.addView(stat("MAÑANA",String.valueOf(nTomorrow),"eventos"),new LinearLayout.LayoutParams(0,dp(108),1));stats.addView(stat("MAIL",String.valueOf(unread),"sin leer"),new LinearLayout.LayoutParams(0,dp(108),1));content.addView(stats,lp());

        LinearLayout actions=new LinearLayout(this);actions.setWeightSum(3);TextView agenda=quick("📅\nAgenda"),mail=quick("✉\nMailPlus"),settings=quick("⚙\nAjustes");actions.addView(agenda,new LinearLayout.LayoutParams(0,dp(82),1));actions.addView(mail,new LinearLayout.LayoutParams(0,dp(82),1));actions.addView(settings,new LinearLayout.LayoutParams(0,dp(82),1));content.addView(actions,lp());
        agenda.setOnClickListener(v->startActivity(new Intent(this,AgendaActivity.class)));mail.setOnClickListener(v->openMailPlus());settings.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));

        sectionTitle("SIGUIENTE");
        EventItem next=firstFuture(all);
        if(next!=null)content.addView(eventCard(next,true),lp());else content.addView(emptyCard("No hay próximos eventos"),lp());

        sectionTitle("PRÓXIMOS EVENTOS");
        int shown=0;for(EventItem e:all){if(e.end*1000L<System.currentTimeMillis())continue;content.addView(eventCard(e,false),smallLp());if(++shown>=4)break;}if(shown==0)content.addView(emptyCard("Tu agenda está libre"),lp());
        TextView seeAll=button("Ver agenda completa  ›");seeAll.setOnClickListener(v->startActivity(new Intent(this,AgendaActivity.class)));content.addView(seeAll,lp());

        sectionTitle("CORREOS RECIENTES");
        int mc=0;for(MailItem m:mails){content.addView(mailCard(m),smallLp());if(++mc>=3)break;}if(mc==0)content.addView(emptyCard("No hay correos en caché"),lp());

        long cu=WidgetCache.updated(this),mu=MailCache.updated(this);long last=Math.max(cu,mu);syncStatus.setText(last>0?"Última sincronización · "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(last)):"Pendiente de sincronización");
    }

    View stat(String a,String b,String c){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);x.setPadding(dp(4),dp(10),dp(4),dp(10));x.setBackground(round(panel,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(108),1);p.setMargins(dp(3),0,dp(3),0);x.setLayoutParams(p);x.addView(t(a,11,true,muted));TextView n=t(b,30,true,text);n.setPadding(0,dp(3),0,0);x.addView(n);x.addView(t(c,12,false,muted));return x;}
    TextView quick(String s){TextView x=t(s,14,true,text);x.setGravity(Gravity.CENTER);x.setBackground(round(panel,18));x.setPadding(dp(4),dp(10),dp(4),dp(10));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(82),1);p.setMargins(dp(3),0,dp(3),0);x.setLayoutParams(p);return x;}
    void sectionTitle(String s){TextView h=t(s,12,true,accent);h.setPadding(dp(4),dp(12),0,dp(8));content.addView(h);}
    View eventCard(EventItem e,boolean hero){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(hero?16:12),dp(12),dp(hero?16:12));row.setBackground(round(hero?panel2:panel,20));int c=ColorUtil.readableCalendarColor(e.calendarColor,true,accent);TextView dot=t("●",18,true,c);row.addView(dot,new LinearLayout.LayoutParams(dp(28),-2));LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);TextView title=t(e.title,hero?18:16,true,text);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);b.addView(title);b.addView(t(eventMeta(e),13,false,muted));if(hero&&!e.location.isBlank()){TextView loc=t("📍 "+e.location,13,false,muted);loc.setMaxLines(1);loc.setEllipsize(android.text.TextUtils.TruncateAt.END);b.addView(loc);}row.addView(b,new LinearLayout.LayoutParams(0,-2,1));row.addView(t("›",28,false,muted));row.setOnClickListener(v->{Intent i=new Intent(this,EventDetailActivity.class);i.putExtra("evt_id",e.evtId);i.putExtra("recurrence_id",e.recurrenceId);startActivity(i);});return row;}
    View mailCard(MailItem m){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(12),dp(12),dp(12));row.setBackground(round(panel,18));TextView mark=t(m.unread?"●":"○",16,true,m.unread?green:muted);row.addView(mark,new LinearLayout.LayoutParams(dp(28),-2));LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);TextView s=t(m.subject==null||m.subject.isBlank()?"(Sin asunto)":m.subject,15,m.unread,text);s.setMaxLines(1);s.setEllipsize(android.text.TextUtils.TruncateAt.END);b.addView(s);TextView f=t(m.from,12,false,muted);f.setMaxLines(1);f.setEllipsize(android.text.TextUtils.TruncateAt.END);b.addView(f);row.addView(b,new LinearLayout.LayoutParams(0,-2,1));row.addView(t("›",25,false,muted));row.setOnClickListener(v->{Intent i=new Intent(this,MailActivity.class);i.putExtra("uid",m.uid);startActivity(i);});return row;}
    View emptyCard(String s){TextView x=t(s,15,false,muted);x.setGravity(Gravity.CENTER);x.setPadding(dp(14),dp(22),dp(14),dp(22));x.setBackground(round(panel,18));return x;}
    TextView button(String s){TextView x=t(s,15,true,text);x.setGravity(Gravity.CENTER);x.setPadding(dp(14),dp(15),dp(14),dp(15));x.setBackground(round(panel2,16));return x;}

    void syncAll(){syncStatus.setText("Sincronizando Calendar y MailPlus…");new Thread(()->{try{WidgetUpdater.updateAll(this);sendBroadcast(new Intent(this,MailWidgetProvider.class).setAction("es.sergio.synologyagenda.MAIL_REFRESH"));Thread.sleep(700);runOnUiThread(()->{render();syncStatus.setText("✓ Sincronización enviada");});}catch(Exception e){runOnUiThread(()->syncStatus.setText("No se pudo actualizar: "+e.getMessage()));}}).start();}
    void openMailPlus(){try{Intent i=getPackageManager().getLaunchIntentForPackage("com.synology.dsmail");if(i!=null){startActivity(i);return;}}catch(Exception ignored){}Toast.makeText(this,"MailPlus no está disponible",Toast.LENGTH_SHORT).show();}
    EventItem firstFuture(List<EventItem> es){long now=System.currentTimeMillis()/1000L;for(EventItem e:es)if(e.end>=now)return e;return null;}
    String eventMeta(EventItem e){Date d=new Date(e.start*1000L);Calendar c=Calendar.getInstance();c.setTime(d);Calendar t=Calendar.getInstance();Calendar tm=(Calendar)t.clone();tm.add(Calendar.DAY_OF_YEAR,1);String day=sameDay(t,c)?"Hoy":sameDay(tm,c)?"Mañana":cap(new SimpleDateFormat("EEE d MMM",new Locale("es","ES")).format(d));String time=e.allDay?"Todo el día":new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d);return day+" · "+time+(e.calendarName.isBlank()?"":" · "+e.calendarName);}
    String greeting(){int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);return h<13?"Buenos días":h<20?"Buenas tardes":"Buenas noches";}
    TextView icon(String s){TextView x=t(s,25,false,text);x.setGravity(Gravity.CENTER);x.setMinWidth(dp(48));x.setMinHeight(dp(48));return x;}
    TextView t(String s,int z,boolean bold,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(z);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    LinearLayout.LayoutParams lp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));return p;}LinearLayout.LayoutParams smallLp(){LinearLayout.LayoutParams p=lp();p.setMargins(0,0,0,dp(7));return p;}
    int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}boolean sameDay(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}String cap(String s){return s==null||s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1);}
}
