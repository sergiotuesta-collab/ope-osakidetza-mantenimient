package es.sergio.synologyagenda;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.*;
import android.view.View;
import android.widget.RemoteViews;
import java.text.*;
import java.util.*;

public final class WidgetUpdater {
    private static final int[] IDS={R.id.e1,R.id.e2,R.id.e3,R.id.e4,R.id.e5,R.id.e6};
    public static void updateAll(Context c) {
        AppWidgetManager m=AppWidgetManager.getInstance(c); ComponentName cn=new ComponentName(c,AgendaWidgetProvider.class);
        int[] ids=m.getAppWidgetIds(cn); for(int id:ids) updateOne(c,m,id);
    }
    public static void updateOne(Context c, AppWidgetManager m, int id) {
        RemoteViews rv=base(c);
        try {
            long now=System.currentTimeMillis()/1000L, end=now+14L*86400L;
            java.util.List<EventItem> ev=new SynologyClient(c).events(now-86400,end);
            int max = m.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,110)>=180?6:3;
            renderEvents(rv,ev,max); rv.setTextViewText(R.id.widget_status,"Actualizado "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));
        } catch(Exception e){ clear(rv); rv.setTextViewText(R.id.e1,"Abre Agenda Synology para conectar"); rv.setTextViewText(R.id.widget_status,e.getMessage()==null?"Error de conexión":e.getMessage()); }
        m.updateAppWidget(id,rv);
    }
    private static RemoteViews base(Context c){
        RemoteViews rv=new RemoteViews(c.getPackageName(),R.layout.widget_agenda);
        Date now=new Date(); rv.setTextViewText(R.id.widget_day,"HOY"); rv.setTextViewText(R.id.widget_date,new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","ES")).format(now));
        Intent ri=new Intent(c,AgendaWidgetProvider.class).setAction("es.sergio.synologyagenda.REFRESH"); PendingIntent rp=PendingIntent.getBroadcast(c,11,ri,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); rv.setOnClickPendingIntent(R.id.widget_refresh,rp);
        Intent ai=new Intent(c,MainActivity.class); PendingIntent ap=PendingIntent.getActivity(c,12,ai,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); rv.setOnClickPendingIntent(R.id.widget_root,ap);
        return rv;
    }
    private static void clear(RemoteViews rv){ for(int x:IDS){rv.setTextViewText(x,"");rv.setViewVisibility(x,View.GONE);} }
    private static void renderEvents(RemoteViews rv,java.util.List<EventItem> ev,int max){ clear(rv); if(ev.isEmpty()){rv.setViewVisibility(R.id.e1,View.VISIBLE);rv.setTextViewText(R.id.e1,"Sin próximos eventos");return;} DateFormat tf=new SimpleDateFormat("HH:mm",Locale.getDefault()); DateFormat df=new SimpleDateFormat("EEE d MMM",new Locale("es","ES")); Calendar today=Calendar.getInstance(); int shown=0; for(EventItem e:ev){ if(shown>=max)break; Date d=new Date(e.start*1000L); Calendar ec=Calendar.getInstance();ec.setTime(d); String when; if(sameDay(today,ec)) when=e.allDay?"Todo el día":tf.format(d); else when=df.format(d)+(e.allDay?" · Todo el día":" · "+tf.format(d)); int vid=IDS[shown++]; rv.setViewVisibility(vid,View.VISIBLE);rv.setTextViewText(vid,when+"   "+e.title); } }
    private static boolean sameDay(Calendar a,Calendar b){return a.get(Calendar.ERA)==b.get(Calendar.ERA)&&a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}
}
