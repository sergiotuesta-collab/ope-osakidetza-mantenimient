package es.sergio.synologyagenda;
public class EventItem {
    public final String title; public final long start; public final boolean allDay;
    public EventItem(String title, long start, boolean allDay) { this.title=title; this.start=start; this.allDay=allDay; }
}
