package es.sergio.synologyagenda;

import android.app.*;
import android.os.Bundle;
import android.widget.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    EditText server,user,password,otp; TextView status; Button connect,refresh;
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main); server=findViewById(R.id.server);user=findViewById(R.id.user);password=findViewById(R.id.password);otp=findViewById(R.id.otp);status=findViewById(R.id.status);connect=findViewById(R.id.connect);refresh=findViewById(R.id.refresh);
        android.content.SharedPreferences p=getSharedPreferences("cfg",MODE_PRIVATE); server.setText(p.getString("server","https://nastuesta.fr3.quickconnect.to")); user.setText(p.getString("user","sergio")); if(CryptoStore.get(this,"password")!=null) password.setHint("Contraseña guardada de forma cifrada");
        connect.setOnClickListener(v->connect()); refresh.setOnClickListener(v->new Thread(()->{runOnUiThread(()->status.setText("Actualizando…"));WidgetUpdater.updateAll(this);runOnUiThread(()->status.setText("Widget actualizado."));}).start()); }
    private void connect(){ String s=server.getText().toString().trim(),u=user.getText().toString().trim(),pw=password.getText().toString(); if(s.isEmpty()||u.isEmpty()){status.setText("Falta servidor o usuario.");return;} try{getSharedPreferences("cfg",MODE_PRIVATE).edit().putString("server",s).putString("user",u).apply(); if(!pw.isEmpty())CryptoStore.put(this,"password",pw); else if(CryptoStore.get(this,"password")==null){status.setText("Introduce la contraseña.");return;}}catch(Exception e){status.setText("No se pudo guardar la contraseña de forma segura.");return;}
        connect.setEnabled(false); status.setText("Conectando con Synology…"); new Thread(()->{try{JSONObject r=new SynologyClient(this).login(otp.getText().toString(),true); if(r.optBoolean("success")){WidgetUpdater.updateAll(this);runOnUiThread(()->{status.setText("Conectado. Ya puedes añadir el widget a la pantalla de inicio.");connect.setEnabled(true);otp.setText("");password.setText("");});}else{int code=r.optJSONObject("error")!=null?r.optJSONObject("error").optInt("code",0):0;runOnUiThread(()->{status.setText("Synology rechazó el inicio de sesión (código "+code+"). Si tienes 2FA, introduce el OTP actual.");connect.setEnabled(true);});}}catch(Exception e){runOnUiThread(()->{status.setText("Error: "+e.getMessage());connect.setEnabled(true);});}}).start(); }
}
