package es.sergio.synologyagenda;

import android.appwidget.*;
import android.content.*;

public class AgendaWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){ for(int id:ids) async(c,m,id); }
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,android.os.Bundle opts){ async(c,m,id); }
    @Override public void onReceive(Context c,Intent i){ super.onReceive(c,i); if("es.sergio.synologyagenda.REFRESH".equals(i.getAction())){ final PendingResult pr=goAsync(); new Thread(()->{try{WidgetUpdater.updateAll(c);}finally{pr.finish();}}).start(); } }
    private void async(Context c,AppWidgetManager m,int id){ final PendingResult pr=goAsync(); new Thread(()->{try{WidgetUpdater.updateOne(c,m,id);}finally{pr.finish();}}).start(); }
}
