# Agenda Synology Widget

Widget Android para mostrar próximos eventos de Synology Calendar usando la Web API oficial a través de HTTPS/QuickConnect.

## Configuración prevista para Sergio
- Servidor preconfigurado: `https://nastuesta.fr3.quickconnect.to`
- Usuario preconfigurado: `sergio`
- La contraseña **no** está incluida en el proyecto.
- Primera conexión: introducir contraseña + OTP. La app solicita un `device token` de Synology para que el dispositivo pueda renovar sesiones sin pedir OTP cada vez.
- Credenciales sensibles (contraseña y device id) se guardan cifradas mediante Android Keystore (AES/GCM).

## Compilar
Abrir la carpeta en Android Studio actual y generar `Build > Build APK(s)`.

## Añadir el widget
En el Samsung: mantener pulsado en la pantalla de inicio > Widgets > Agenda Synology.

## Nota
Es una primera versión y conviene probarla con el NAS real. El acceso a `/webapi/query.cgi` por QuickConnect ya se comprobó correctamente desde 5G. Si Synology devuelve un formato distinto para login/eventos en ese NAS, habrá que ajustar el cliente a la respuesta real.
