package es.sergio.synologyagenda;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.util.Base64;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class EventDetailActivity extends Activity {
    static final int PICK_IMAGE=4102, PICK_CONTACT=4103;
    long id,start,end; String rec="", calendarColor=""; EditText title,desc,loc; Switch all; TextView bs,be,save,status,calLabel,share,deleteBtn,mapBtn,attachmentInfo,addImageBtn,removeImageBtn; ImageView imagePreview; boolean fromWidget;
    JSONArray attachments=new JSONArray(); int initialAttachmentCount=0;
    LinearLayout peopleBox; JSONArray people=new JSONArray();
    final int bg=Color.rgb(8,14,24), panel=Color.rgb(19,29,43), field=Color.rgb(25,37,53), text=Color.rgb(245,247,250), muted=Color.rgb(166,181,203), accent=Color.rgb(69,139,255);

    public void onCreate(Bundle b){super.onCreate(b);id=getIntent().getLongExtra("evt_id",0);rec=getIntent().getStringExtra("recurrence_id");if(rec==null)rec="";fromWidget=getIntent().getBooleanExtra("from_widget",false);build();load();}
    void build(){
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.setBackgroundColor(bg);
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18),dp(10),dp(18),dp(34));

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(0,dp(4),0,dp(14));
        TextView back=t("‹",40,false,Color.rgb(126,174,255)); back.setGravity(Gravity.CENTER); back.setMinWidth(dp(48));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView h=t("Editar evento",30,true,text); calLabel=t("Cargando calendario…",14,true,Color.rgb(126,174,255));
        titles.addView(h); titles.addView(calLabel); top.addView(back); top.addView(titles,new LinearLayout.LayoutParams(0,-2,1)); l.addView(top); back.setOnClickListener(v->onBackPressed());

        title=e("Título del evento"); title.setTextSize(21); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        l.addView(sectionCard("▣", "Título", title),lp());

        LinearLayout allRow=new LinearLayout(this); allRow.setGravity(Gravity.CENTER_VERTICAL); allRow.setPadding(dp(4),0,dp(2),0);
        LinearLayout allText=new LinearLayout(this); allText.setOrientation(LinearLayout.VERTICAL);
        allText.addView(t("Todo el día",18,true,text)); allText.addView(t("Ocupa días completos",13,false,muted));
        all=new Switch(this); allRow.addView(allText,new LinearLayout.LayoutParams(0,-2,1)); allRow.addView(all);
        l.addView(sectionCard("▦", null, allRow),lp());

        LinearLayout dates=new LinearLayout(this); dates.setOrientation(LinearLayout.VERTICAL);
        bs=dateAction("Inicio"); be=dateAction("Fin (último día)"); dates.addView(bs); dates.addView(divider()); dates.addView(be);
        l.addView(sectionCard("▦", "Fechas", dates),lp());

        loc=e("Escribe una ubicación…"); l.addView(sectionCard("●", "Ubicación", loc),lp());
        desc=e("Añade una descripción…"); desc.setMinLines(4); desc.setGravity(Gravity.TOP); l.addView(sectionCard("≡", "Descripción (opcional)", desc),lp());

        LinearLayout attachmentBox=new LinearLayout(this); attachmentBox.setOrientation(LinearLayout.VERTICAL);
        attachmentInfo=t("Sin imágenes adjuntas",14,false,muted); attachmentBox.addView(attachmentInfo);
        imagePreview=new ImageView(this); imagePreview.setAdjustViewBounds(true); imagePreview.setScaleType(ImageView.ScaleType.CENTER_CROP); imagePreview.setVisibility(View.GONE);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(170)); ip.setMargins(0,dp(10),0,dp(10)); attachmentBox.addView(imagePreview,ip);
        LinearLayout attButtons=new LinearLayout(this);attButtons.setOrientation(LinearLayout.HORIZONTAL);
        addImageBtn=action("＋  Añadir imagen"); removeImageBtn=action("−  Quitar última"); removeImageBtn.setVisibility(View.GONE);
        attButtons.addView(addImageBtn,new LinearLayout.LayoutParams(0,-2,1)); LinearLayout.LayoutParams rb=new LinearLayout.LayoutParams(0,-2,1);rb.setMargins(dp(8),0,0,0);attButtons.addView(removeImageBtn,rb);attachmentBox.addView(attButtons);
        TextView note=t("La imagen se adjunta al propio evento de Synology Calendar.",12,false,muted);note.setPadding(2,dp(8),0,0);attachmentBox.addView(note);
        l.addView(sectionCard("▧", "Imágenes adjuntas", attachmentBox),lp());

        peopleBox=new LinearLayout(this); peopleBox.setOrientation(LinearLayout.VERTICAL);
        TextView addPerson=action("＋  Añadir desde contactos"); addPerson.setOnClickListener(v->pickContact());
        peopleBox.addView(addPerson); renderPeople();
        TextView peopleNote=t("Los teléfonos se guardan de forma privada en Agenda Synology para este evento. No modifican los participantes oficiales del calendario.",12,false,muted); peopleNote.setPadding(2,dp(8),0,0); peopleBox.addView(peopleNote);
        l.addView(sectionCard("♟", "Personas", peopleBox),lp());

        LinearLayout quick=new LinearLayout(this);quick.setOrientation(LinearLayout.HORIZONTAL);
        mapBtn=action("⌖  Navegar"); share=action("↗  Compartir"); quick.addView(mapBtn,new LinearLayout.LayoutParams(0,-2,1)); LinearLayout.LayoutParams q2=new LinearLayout.LayoutParams(0,-2,1);q2.setMargins(dp(8),0,0,0);quick.addView(share,q2);l.addView(quick,lp());

        save=action("✓  Guardar cambios"); save.setTextColor(Color.WHITE); save.setBackground(round(accent,20)); save.setGravity(Gravity.CENTER); save.setTypeface(Typeface.DEFAULT,Typeface.BOLD); save.setTextSize(17); save.setPadding(dp(14),dp(18),dp(14),dp(18)); l.addView(save,lp());
        deleteBtn=action("🗑  Borrar evento");deleteBtn.setTextColor(Color.rgb(255,130,130));deleteBtn.setGravity(Gravity.CENTER);l.addView(deleteBtn,lp());
        status=t("Cargando evento…",14,false,muted); status.setGravity(Gravity.CENTER); status.setPadding(dp(10),dp(8),dp(10),dp(12)); l.addView(status);
        sv.addView(l); setContentView(sv);
        bs.setOnClickListener(v->pick(true)); be.setOnClickListener(v->pick(false)); save.setOnClickListener(v->save()); all.setOnCheckedChangeListener((v,c)->labels()); share.setOnClickListener(v->shareEvent()); mapBtn.setOnClickListener(v->openMap()); deleteBtn.setOnClickListener(v->confirmDelete()); addImageBtn.setOnClickListener(v->pickImage()); removeImageBtn.setOnClickListener(v->removeLastAddedImage());
    }
    android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    android.graphics.drawable.GradientDrawable bordered(int color,int radius){android.graphics.drawable.GradientDrawable g=round(color,radius);g.setStroke(dp(1),Color.rgb(35,52,74));return g;}
    View sectionCard(String icon,String label,View child){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setPadding(dp(16),dp(15),dp(14),dp(15)); box.setBackground(bordered(panel,20));
        TextView ic=t(icon,20,true,Color.rgb(126,174,255)); ic.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL); ic.setMinWidth(dp(34)); box.addView(ic);
        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(8),0,0,0);
        if(label!=null&&!label.isBlank()){TextView lab=t(label,14,false,muted);lab.setPadding(dp(2),0,0,dp(7));body.addView(lab);}
        body.addView(child,new LinearLayout.LayoutParams(-1,-2)); box.addView(body,new LinearLayout.LayoutParams(0,-2,1)); return box;
    }
    View divider(){View v=new View(this);v.setBackgroundColor(Color.rgb(35,52,74));v.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(1)));return v;}
    LinearLayout.LayoutParams lp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));return p;}
    TextView action(String s){TextView x=t(s,16,false,text);x.setPadding(dp(14),dp(16),dp(14),dp(16));x.setBackground(round(field,16));return x;}
    TextView dateAction(String s){TextView x=t(s,17,false,text);x.setPadding(dp(4),dp(12),dp(4),dp(12));x.setCompoundDrawablePadding(dp(8));return x;}
    EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setHintTextColor(Color.rgb(112,130,154));x.setTextColor(text);x.setTextSize(17);x.setPadding(dp(13),dp(12),dp(13),dp(12));x.setBackground(bordered(field,14));return x;}
    void load(){
        EventItem cached=WidgetCache.find(this,id,rec);if(cached!=null){start=cached.start;end=cached.end;title.setText(cached.title);all.setChecked(cached.allDay);calendarColor=cached.calendarColor;setCalendar(cached.calendarName,cached.calendarColor);labels();}
        new Thread(()->{try{JSONObject o=new SynologyClient(this).getEvent(id,rec);runOnUiThread(()->apply(o));}catch(Exception e){runOnUiThread(()->status.setText("No se pudo cargar el evento: "+e.getMessage()));}}).start();
    }
    void apply(JSONObject o){loadPeople();title.setText(o.optString("summary",title.getText().toString()));start=o.optLong("dtstart",start);end=o.optLong("dtend",end);all.setChecked(o.optBoolean("is_all_day",all.isChecked()));desc.setText(o.optString("description",""));JSONObject li=o.optJSONObject("location_info");if(li!=null)loc.setText(li.optString("name",li.optString("address","")));JSONArray a=o.optJSONArray("attachments");attachments=cloneArray(a);initialAttachmentCount=attachments.length();imagePreview.setVisibility(View.GONE);removeImageBtn.setVisibility(View.GONE);updateAttachmentInfo();EventItem cached=WidgetCache.find(this,id,rec);if(cached!=null)setCalendar(cached.calendarName,cached.calendarColor);labels();status.setText(rec.isBlank()?"Puedes modificar y guardar este evento.":"Estás editando solo esta aparición del evento recurrente.");}
    void setCalendar(String name,String color){calendarColor=color==null?"":color;int c=ColorUtil.readableCalendarColor(calendarColor,true,Color.rgb(137,180,255));calLabel.setText((name==null||name.isBlank()?"Calendario Synology":name));calLabel.setTextColor(c);}
    void labels(){
        if(start<=0||end<=0)return;
        boolean ad=all.isChecked();
        SimpleDateFormat d=ad?new SimpleDateFormat("EEE d MMM yyyy",new Locale("es","ES")):new SimpleDateFormat("EEE d MMM yyyy · HH:mm",new Locale("es","ES"));
        long shownEnd=ad && end>start ? end-86400L : end;
        bs.setText("Inicio\n"+cap(d.format(new Date(start*1000L)))+"   ›");
        be.setText((ad?"Fin (último día)":"Fin")+"\n"+cap(d.format(new Date(shownEnd*1000L)))+"   ›");
    }
    void pick(boolean st){
        boolean ad=all.isChecked();
        long val=st?start:(ad && end>start?end-86400L:end);
        Calendar c=Calendar.getInstance();if(val>0)c.setTimeInMillis(val*1000L);
        new DatePickerDialog(this,(v,y,m,d)->{
            if(ad){
                Calendar u=Calendar.getInstance(TimeZone.getTimeZone("UTC"));u.clear();u.set(y,m,d,0,0,0);
                long sec=u.getTimeInMillis()/1000L;
                if(st) start=sec; else end=sec+86400L;
                labels();
            }else{
                c.set(y,m,d);
                new TimePickerDialog(this,(tv,h,min)->{c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,min);c.set(Calendar.SECOND,0);set(st,c);},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
            }
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    void set(boolean st,Calendar c){if(st)start=c.getTimeInMillis()/1000L;else end=c.getTimeInMillis()/1000L;labels();}

    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");try{startActivityForResult(i,PICK_IMAGE);}catch(Exception e){status.setText("No se pudo abrir el selector de imágenes.");}}
    void pickContact(){Intent i=new Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI);try{startActivityForResult(i,PICK_CONTACT);}catch(Exception e){status.setText("No se pudo abrir la agenda del teléfono.");}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK||data==null||data.getData()==null)return; Uri u=data.getData();
        if(requestCode==PICK_CONTACT){addPickedContact(u);return;} if(requestCode!=PICK_IMAGE)return;
        status.setText("Preparando imagen…");new Thread(()->{try{ImageData im=compressImage(u);JSONObject at=new JSONObject();at.put("is_syno",false);at.put("property_value",Base64.encodeToString(im.bytes,Base64.NO_WRAP));at.put("filename",im.name);at.put("fmttype","image/jpeg");at.put("value","BINARY");at.put("encoding","BASE64");attachments.put(at);Bitmap preview=BitmapFactory.decodeByteArray(im.bytes,0,im.bytes.length);runOnUiThread(()->{imagePreview.setImageBitmap(preview);imagePreview.setVisibility(View.VISIBLE);removeImageBtn.setVisibility(View.VISIBLE);updateAttachmentInfo();status.setText("Imagen preparada. Pulsa Guardar cambios para subirla al evento.");});}catch(Exception e){runOnUiThread(()->status.setText("No se pudo preparar la imagen: "+e.getMessage()));}}).start();
    }
    void addPickedContact(Uri uri){
        String name="",phone=""; try(Cursor c=getContentResolver().query(uri,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){if(c!=null&&c.moveToFirst()){name=c.getString(0);phone=c.getString(1);}}catch(Exception e){status.setText("No se pudo leer el contacto.");return;}
        if(phone==null||phone.isBlank()){status.setText("Ese contacto no tiene teléfono.");return;} if(name==null||name.isBlank())name=phone;
        try{for(int i=0;i<people.length();i++)if(phone.equals(people.optJSONObject(i).optString("phone"))){status.setText("Ese teléfono ya está añadido.");return;} JSONObject o=new JSONObject();o.put("name",name);o.put("phone",phone);people.put(o);savePeople();renderPeople();status.setText(name+" añadido al evento.");}catch(Exception e){status.setText("No se pudo guardar el contacto.");}
    }
    String peopleKey(){return "event_people_"+id+"_"+(rec==null?"":rec);}
    void loadPeople(){try{String raw=getSharedPreferences("event_people",MODE_PRIVATE).getString(peopleKey(),"[]");people=new JSONArray(raw);}catch(Exception e){people=new JSONArray();}renderPeople();}
    void savePeople(){getSharedPreferences("event_people",MODE_PRIVATE).edit().putString(peopleKey(),people.toString()).apply();}
    void renderPeople(){if(peopleBox==null)return;while(peopleBox.getChildCount()>1)peopleBox.removeViewAt(1);for(int i=0;i<people.length();i++){JSONObject o=people.optJSONObject(i);if(o==null)continue;final int idx=i;String n=o.optString("name","Contacto"),ph=o.optString("phone","");LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),dp(8),dp(2),dp(4));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.addView(t(n,16,true,text));info.addView(t(ph,14,false,muted));TextView call=action("📞");call.setGravity(Gravity.CENTER);call.setOnClickListener(v->dial(ph));TextView remove=action("×");remove.setGravity(Gravity.CENTER);remove.setOnClickListener(v->{people.remove(idx);savePeople();renderPeople();});row.addView(info,new LinearLayout.LayoutParams(0,-2,1));row.addView(call,new LinearLayout.LayoutParams(dp(58),-2));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(dp(50),-2);rp.setMargins(dp(6),0,0,0);row.addView(remove,rp);peopleBox.addView(row,Math.min(1+i,peopleBox.getChildCount()));}}
    void dial(String phone){try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(phone))));}catch(Exception e){status.setText("No se pudo abrir el teléfono.");}}

    void removeLastAddedImage(){if(attachments.length()<=initialAttachmentCount)return;attachments.remove(attachments.length()-1);if(attachments.length()<=initialAttachmentCount){imagePreview.setVisibility(View.GONE);removeImageBtn.setVisibility(View.GONE);}updateAttachmentInfo();status.setText("Imagen retirada antes de guardar.");}
    void updateAttachmentInfo(){int total=attachments==null?0:attachments.length();int added=Math.max(0,total-initialAttachmentCount);if(total==0)attachmentInfo.setText("Sin imágenes adjuntas");else if(added>0)attachmentInfo.setText(total+" adjunto"+(total==1?"":"s")+" · "+added+" nuevo"+(added==1?"":"s")+" sin guardar");else attachmentInfo.setText(total+" adjunto"+(total==1?"":"s")+" en Synology Calendar");}
    ImageData compressImage(Uri uri)throws Exception{Bitmap src;try(InputStream in=getContentResolver().openInputStream(uri)){src=BitmapFactory.decodeStream(in);}if(src==null)throw new IOException("formato de imagen no compatible");int w=src.getWidth(),h=src.getHeight(),max=1600;if(Math.max(w,h)>max){float s=max/(float)Math.max(w,h);Bitmap scaled=Bitmap.createScaledBitmap(src,Math.max(1,Math.round(w*s)),Math.max(1,Math.round(h*s)),true);if(scaled!=src)src.recycle();src=scaled;}byte[] out=null;int q=84;while(q>=58){ByteArrayOutputStream bos=new ByteArrayOutputStream();src.compress(Bitmap.CompressFormat.JPEG,q,bos);out=bos.toByteArray();if(out.length<=700*1024)break;q-=7;}if(src!=null&&!src.isRecycled())src.recycle();if(out==null||out.length==0)throw new IOException("imagen vacía");if(out.length>1000*1024)throw new IOException("la imagen sigue siendo demasiado grande");String name=queryName(uri);if(name==null||name.isBlank())name="imagen_evento_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";int dot=name.lastIndexOf('.');if(dot>0)name=name.substring(0,dot)+".jpg";else name=name+".jpg";return new ImageData(out,name);}
    String queryName(Uri uri){try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return null;}
    static class ImageData{final byte[] bytes;final String name;ImageData(byte[] b,String n){bytes=b;name=n;}}
    static JSONArray cloneArray(JSONArray a){try{return a==null?new JSONArray():new JSONArray(a.toString());}catch(Exception e){return new JSONArray();}}

    void save(){
        String ti=title.getText().toString().trim();if(ti.isEmpty()){status.setText("El evento necesita un título.");return;}if(end<=start){status.setText("La fecha u hora de fin debe ser posterior al inicio.");return;}
        final boolean ad=all.isChecked(); final String wantedDesc=desc.getText().toString(); final String wantedLoc=loc.getText().toString().trim(); final JSONArray wantedAttachments=cloneArray(attachments); final int wantedAttachmentCount=wantedAttachments.length();
        save.setEnabled(false);addImageBtn.setEnabled(false);status.setText("Guardando y verificando en Synology…");
        new Thread(()->{try{
            SynologyClient client=new SynologyClient(this);
            client.updateEvent(id,rec,ti,ad,start,end,wantedDesc,wantedLoc,wantedAttachments);
            JSONObject fresh=client.getEvent(id,rec);
            String freshLoc=""; JSONObject li=fresh.optJSONObject("location_info"); if(li!=null) freshLoc=li.optString("name",li.optString("address",""));
            JSONArray freshAttachments=fresh.optJSONArray("attachments");int freshCount=freshAttachments==null?0:freshAttachments.length();
            if(!ti.equals(fresh.optString("summary","")) || ad!=fresh.optBoolean("is_all_day",false) || start!=fresh.optLong("dtstart",-1) || end!=fresh.optLong("dtend",-1) || !wantedLoc.equals(freshLoc) || freshCount!=wantedAttachmentCount)
                throw new IOException("Synology respondió, pero la verificación del cambio no coincide");
            WidgetUpdater.updateAll(this);
            final JSONObject verified=fresh;
            runOnUiThread(()->{apply(verified);status.setText("✓ Guardado y verificado en Synology Calendar");save.setEnabled(true);addImageBtn.setEnabled(true);showSuccess();});
        }catch(Exception e){runOnUiThread(()->{status.setText("No se pudo guardar: "+e.getMessage());save.setEnabled(true);addImageBtn.setEnabled(true);});}}).start();
    }
    void showSuccess(){
        new AlertDialog.Builder(this)
                .setTitle("✓ Evento actualizado")
                .setMessage("Synology Calendar ha confirmado el cambio y la app lo ha verificado volviendo a leer el evento, incluidos los adjuntos.")
                .setPositiveButton("Aceptar",null)
                .show();
    }

    void shareEvent(){
        String body=title.getText().toString().trim()+"\n"+bs.getText()+"\n"+be.getText(); if(!loc.getText().toString().trim().isBlank())body+="\n📍 "+loc.getText().toString().trim(); if(!desc.getText().toString().trim().isBlank())body+="\n\n"+desc.getText().toString().trim();
        Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,title.getText().toString().trim());i.putExtra(Intent.EXTRA_TEXT,body);startActivity(Intent.createChooser(i,"Compartir evento"));
    }
    void openMap(){ String q=loc.getText().toString().trim(); if(q.isBlank()){status.setText("Añade una ubicación para navegar.");return;} Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(q))); try{startActivity(i);}catch(Exception e){status.setText("No hay una app de mapas disponible.");} }
    void confirmDelete(){
        String msg=rec.isBlank()?"Se borrará este evento de Synology Calendar.":"Se borrará solo esta aparición del evento recurrente.";
        new AlertDialog.Builder(this).setTitle("¿Borrar evento?").setMessage(msg+" Esta acción no se puede deshacer desde la app.").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->doDelete()).show();
    }
    void doDelete(){ deleteBtn.setEnabled(false);save.setEnabled(false);status.setText("Borrando en Synology…"); new Thread(()->{try{new SynologyClient(this).deleteEvent(id,rec);WidgetUpdater.updateAll(this);runOnUiThread(()->{Toast.makeText(this,"Evento borrado",Toast.LENGTH_SHORT).show();finish();});}catch(Exception e){runOnUiThread(()->{status.setText("No se pudo borrar: "+e.getMessage());deleteBtn.setEnabled(true);save.setEnabled(true);});}}).start(); }

    @Override public void onBackPressed(){if(fromWidget){Intent i=new Intent(this,AgendaActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}else super.onBackPressed();}
    TextView t(String s,int z,boolean bo,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(z);if(bo)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}String cap(String s){return s==null||s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1);}
}
