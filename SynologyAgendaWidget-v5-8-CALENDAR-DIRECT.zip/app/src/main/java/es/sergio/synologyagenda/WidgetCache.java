package es.sergio.synologyagenda;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public final class WidgetCache {
    private WidgetCache() {}
    public static void save(Context c, List<EventItem> events){
        JSONArray a=new JSONArray();
        try{
            for(EventItem e:events){
                JSONObject o=new JSONObject();
                o.put("evtId",e.evtId);o.put("recurrenceId",e.recurrenceId);o.put("title",e.title);
                o.put("start",e.start);o.put("end",e.end);o.put("allDay",e.allDay);
                o.put("calId",e.calId);o.put("originalCalId",e.originalCalId);o.put("davEtag",e.davEtag);o.put("calendarName",e.calendarName);o.put("calendarColor",e.calendarColor);o.put("description",e.description);o.put("location",e.location);a.put(o);
            }
        }catch(Exception ignored){}
        c.getSharedPreferences("widget_cache",Context.MODE_PRIVATE).edit().putString("events",a.toString()).putLong("updated",System.currentTimeMillis()).apply();
    }
    public static List<EventItem> load(Context c){
        List<EventItem> out=new ArrayList<>();
        String raw=c.getSharedPreferences("widget_cache",Context.MODE_PRIVATE).getString("events","[]");
        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                out.add(new EventItem(o.optLong("evtId"),o.optString("recurrenceId",""),o.optString("title","(Sin título)"),
                        o.optLong("start"),o.optLong("end"),o.optBoolean("allDay"),
                        o.optString("calId",""),o.optString("originalCalId",""),o.optString("davEtag",""),o.optString("calendarName",""),o.optString("calendarColor",""),o.optString("description",""),o.optString("location","")));
            }
        }catch(Exception ignored){}
        out.sort(Comparator.comparingLong((EventItem e)->e.start).thenComparingLong(e->e.evtId));
        return out;
    }
    public static EventItem find(Context c,long evtId,String recurrenceId){
        String rec=recurrenceId==null?"":recurrenceId;
        for(EventItem e:load(c)) if(e.evtId==evtId && e.recurrenceId.equals(rec)) return e;
        for(EventItem e:load(c)) if(e.evtId==evtId) return e;
        return null;
    }
    public static long updated(Context c){ return c.getSharedPreferences("widget_cache",Context.MODE_PRIVATE).getLong("updated",0); }
}
