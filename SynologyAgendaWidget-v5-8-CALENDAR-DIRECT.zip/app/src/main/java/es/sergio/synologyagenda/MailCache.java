package es.sergio.synologyagenda;
import android.content.*;import org.json.*;import java.util.*;
public final class MailCache{
 public static void save(Context c,List<MailItem>x){JSONArray a=new JSONArray();try{for(MailItem m:x){JSONObject o=new JSONObject();o.put("u",m.uid);o.put("f",m.from);o.put("s",m.subject);o.put("d",m.date);o.put("n",m.unread);a.put(o);}}catch(Exception e){}c.getSharedPreferences("mail_cache",0).edit().putString("m",a.toString()).putLong("u",System.currentTimeMillis()).apply();}
 public static List<MailItem> load(Context c){List<MailItem>o=new ArrayList<>();try{JSONArray a=new JSONArray(c.getSharedPreferences("mail_cache",0).getString("m","[]"));for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);o.add(new MailItem(j.optLong("u"),j.optString("f"),j.optString("s"),j.optString("d"),j.optBoolean("n")));}}catch(Exception e){}return o;}
 public static void markRead(Context c,long uid){List<MailItem> old=load(c),out=new ArrayList<>();for(MailItem m:old)out.add(m.uid==uid?new MailItem(m.uid,m.from,m.subject,m.date,false):m);save(c,out);}
 public static void remove(Context c,long uid){List<MailItem> old=load(c),out=new ArrayList<>();for(MailItem m:old)if(m.uid!=uid)out.add(m);save(c,out);}
 public static long updated(Context c){return c.getSharedPreferences("mail_cache",0).getLong("u",0);}
}
