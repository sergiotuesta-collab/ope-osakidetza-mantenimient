package es.sergio.synologyagenda;

public class EventItem {
    public final long evtId; public final String recurrenceId,title,description,location; public final long start,end; public final boolean allDay;
    public final String calId,originalCalId,davEtag,calendarName,calendarColor;
    public EventItem(long evtId,String recurrenceId,String title,long start,long end,boolean allDay,String calId,String originalCalId,String davEtag,String calendarName,String calendarColor,String description,String location){
        this.evtId=evtId;this.recurrenceId=recurrenceId==null?"":recurrenceId;this.title=title==null||title.isBlank()?"(Sin título)":title;this.start=start;this.end=end;this.allDay=allDay;this.calId=calId==null?"":calId;this.originalCalId=originalCalId==null?"":originalCalId;this.davEtag=davEtag==null?"":davEtag;this.calendarName=calendarName==null?"":calendarName;this.calendarColor=calendarColor==null?"":calendarColor;this.description=description==null?"":description;this.location=location==null?"":location;
    }
    public String stableKey(){return evtId+"|"+recurrenceId;}
}
