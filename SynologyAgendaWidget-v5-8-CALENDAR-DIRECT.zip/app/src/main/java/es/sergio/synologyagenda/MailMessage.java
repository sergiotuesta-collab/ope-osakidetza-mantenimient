package es.sergio.synologyagenda;

public class MailMessage {
    public final long uid;
    public final String from;
    public final String fromAddress;
    public final String to;
    public final String subject;
    public final String date;
    public final String body;
    public final boolean html;

    public MailMessage(long uid, String from, String fromAddress, String to,
                       String subject, String date, String body, boolean html) {
        this.uid = uid;
        this.from = from == null ? "" : from;
        this.fromAddress = fromAddress == null ? "" : fromAddress;
        this.to = to == null ? "" : to;
        this.subject = subject == null ? "" : subject;
        this.date = date == null ? "" : date;
        this.body = body == null ? "" : body;
        this.html = html;
    }
}
