package es.sergio.synologyagenda;

import android.content.Context;
import android.content.SharedPreferences;

public final class WidgetPrefs {
    private WidgetPrefs() {}
    private static SharedPreferences p(Context c){ return c.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE); }
    public static int days(Context c){ return p(c).getInt("days",30); }
    public static int textSize(Context c){ return p(c).getInt("text_size",16); }
    public static int density(Context c){ return p(c).getInt("density",1); }
    public static boolean hidePast(Context c){ return p(c).getBoolean("hide_past",true); }
    public static boolean showStatus(Context c){ return p(c).getBoolean("show_status",true); }
    public static boolean showHeader(Context c){ return p(c).getBoolean("show_header",true); }
    public static boolean showDayHeaders(Context c){ return p(c).getBoolean("day_headers",true); }
    public static boolean amoled(Context c){ return p(c).getBoolean("amoled",false); }
    public static int detailMode(Context c){ return p(c).getInt("detail_mode",1); }
}
