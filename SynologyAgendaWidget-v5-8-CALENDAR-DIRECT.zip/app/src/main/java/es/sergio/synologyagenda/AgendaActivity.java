package es.sergio.synologyagenda;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class AgendaActivity extends Activity {
    LinearLayout list; TextView status;
    private boolean returnHomeAfterCalendar=false;
    final int bg=Color.rgb(13,15,18), card=Color.rgb(27,30,35), text=Color.rgb(245,247,250), muted=Color.rgb(166,173,184);

    @Override public void onCreate(Bundle b){super.onCreate(b);build();render();refresh();}

    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(12),dp(18),dp(12)); root.setBackgroundColor(bg);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView h=t("Agenda",30,true,text); titles.addView(h);
        TextView sub=t(cap(new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","ES")).format(new Date())),14,false,muted); titles.addView(sub);
        bar.addView(titles,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
        TextView calendar=icon("▦"); calendar.setContentDescription("Abrir Synology Calendar");
        TextView refresh=icon("↻"); TextView settings=icon("⚙"); bar.addView(calendar); bar.addView(refresh); bar.addView(settings); root.addView(bar);
        status=t("",12,false,muted); status.setPadding(0,dp(3),0,dp(5)); root.addView(status);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        calendar.setOnClickListener(v->openSynologyCalendar());
        settings.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));
        refresh.setOnClickListener(v->refresh());
    }

    void render(){
        list.removeAllViews(); List<EventItem> es=EventFilter.upcoming(this,WidgetCache.load(this));
        String last=""; SimpleDateFormat key=new SimpleDateFormat("yyyyMMdd",Locale.US), day=new SimpleDateFormat("EEEE d 'de' MMMM",new Locale("es","ES")),time=new SimpleDateFormat("HH:mm",Locale.getDefault());
        Calendar today=Calendar.getInstance();
        for(EventItem e:es){
            Date d=new Date(e.start*1000L); String k=key.format(d);
            if(!k.equals(last)){
                Calendar ec=Calendar.getInstance(); ec.setTime(d); String label=cap(day.format(d));
                if(sameDay(today,ec)) label="HOY · "+label; else { Calendar tm=(Calendar)today.clone(); tm.add(Calendar.DAY_OF_YEAR,1); if(sameDay(tm,ec))label="MAÑANA · "+label; }
                TextView dh=t(label.toUpperCase(new Locale("es","ES")),12,true,Color.rgb(137,180,255)); dh.setPadding(dp(4),dp(17),0,dp(7)); list.addView(dh); last=k;
            }
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(12),dp(11),dp(12),dp(11)); row.setBackgroundColor(card);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.setMargins(0,0,0,dp(7)); row.setLayoutParams(rp);
            TextView marker=new TextView(this); marker.setText("●"); int c=ColorUtil.readableCalendarColor(e.calendarColor,true,Color.rgb(115,165,255)); marker.setTextColor(c); marker.setTextSize(15); row.addView(marker,new LinearLayout.LayoutParams(dp(22),-2));
            LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
            TextView title=t(e.title,17,true,c); title.setMaxLines(2); title.setEllipsize(android.text.TextUtils.TruncateAt.END); body.addView(title);
            String meta=(e.allDay?"Todo el día":time.format(d)); if(!e.calendarName.isBlank())meta+="  ·  "+e.calendarName;
            TextView m=t(meta,13,false,muted); m.setPadding(0,dp(3),0,0); body.addView(m);
            row.addView(body,new LinearLayout.LayoutParams(0,-2,1)); TextView che=t("›",28,false,muted); row.addView(che);
            row.setOnClickListener(v->{Intent i=new Intent(this,EventDetailActivity.class);i.putExtra("evt_id",e.evtId);i.putExtra("recurrence_id",e.recurrenceId);startActivity(i);}); list.addView(row);
        }
        if(es.isEmpty()){ TextView empty=t("No hay próximos eventos.",17,false,muted); empty.setGravity(Gravity.CENTER); empty.setPadding(0,dp(70),0,0); list.addView(empty); }
        long up=WidgetCache.updated(this); status.setText(up>0?"Actualizado a las "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(up)):"Pendiente de actualización");
    }

    void refresh(){ status.setText("Actualizando Calendar y widgets…"); new Thread(()->{WidgetUpdater.updateAll(this);runOnUiThread(this::render);}).start(); }

    private void openSynologyCalendar(){
        String server=getSharedPreferences("cfg",MODE_PRIVATE).getString("server","https://nastuesta.fr3.quickconnect.to");
        if(server==null||server.trim().isEmpty())server="https://nastuesta.fr3.quickconnect.to";
        server=server.trim();
        while(server.endsWith("/"))server=server.substring(0,server.length()-1);
        String url=server+"/?launchApp=SYNO.SDS.Calendar.Application";
        Intent web=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url));
        returnHomeAfterCalendar=true;
        try{
            startActivity(web);
        }catch(Exception ex){
            try{
                Intent mail=getPackageManager().getLaunchIntentForPackage("com.synology.dsmail");
                if(mail!=null)startActivity(mail);
                else throw new Exception("MailPlus no instalado");
            }catch(Exception ex2){
                returnHomeAfterCalendar=false;
                Toast.makeText(this,"No se pudo abrir Synology Calendar",Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onResume(){
        super.onResume();
        if(returnHomeAfterCalendar){
            returnHomeAfterCalendar=false;
            finish();
            moveTaskToBack(true);
        }
    }

    @Override public void onBackPressed(){ moveTaskToBack(true); }
    private TextView icon(String s){TextView x=t(s,25,false,text);x.setGravity(Gravity.CENTER);x.setMinWidth(dp(48));x.setMinHeight(dp(48));return x;}
    private TextView t(String s,int z,boolean bold,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(z);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} private boolean sameDay(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);} private String cap(String s){return s==null||s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1);}
}
