package es.sergio.synologyagenda;
public class MailItem{public final long uid;public final String from,subject,date;public final boolean unread;public MailItem(long uid,String f,String s,String d,boolean u){this.uid=uid;from=f;subject=s;date=d;unread=u;}}
