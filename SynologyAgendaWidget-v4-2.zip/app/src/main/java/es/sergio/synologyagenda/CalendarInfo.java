package es.sergio.synologyagenda;

public class CalendarInfo {
    public final String calId;
    public final String originalCalId;
    public final String name;
    public final String color;
    public final boolean writable;
    public final boolean defaultCalendar;

    public CalendarInfo(String calId, String originalCalId, String name, String color, boolean writable, boolean defaultCalendar) {
        this.calId = calId == null ? "" : calId;
        this.originalCalId = originalCalId == null ? this.calId : originalCalId;
        this.name = name == null || name.isBlank() ? "Calendario" : name;
        this.color = color == null ? "" : color;
        this.writable = writable;
        this.defaultCalendar = defaultCalendar;
    }
}
