package es.sergio.synologyagenda;
import android.graphics.Color;
public final class ColorUtil {
    private ColorUtil(){}
    public static int parseCalendarColor(String s, int fallback){
        try { if(s!=null && s.matches("#[0-9a-fA-F]{6,8}")) return Color.parseColor(s.substring(0,7)); } catch(Exception ignored){}
        return fallback;
    }
    public static int readableCalendarColor(String s, boolean darkBackground, int fallback){
        int c=parseCalendarColor(s,fallback);
        double lum=(0.2126*Color.red(c)+0.7152*Color.green(c)+0.0722*Color.blue(c))/255.0;
        if(darkBackground && lum<0.32) return blend(c, Color.WHITE, .38f);
        if(!darkBackground && lum>0.80) return blend(c, Color.BLACK, .34f);
        return c;
    }
    private static int blend(int a,int b,float f){return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f));}
}
