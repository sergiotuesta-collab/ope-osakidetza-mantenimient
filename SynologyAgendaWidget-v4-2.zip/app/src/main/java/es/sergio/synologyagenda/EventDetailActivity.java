package es.sergio.synologyagenda;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class EventDetailActivity extends Activity {
    long id,start,end; String rec="", calendarColor=""; EditText title,desc,loc; Switch all; TextView bs,be,save,status,calLabel; boolean fromWidget;
    final int bg=Color.rgb(13,15,18), panel=Color.rgb(27,30,35), text=Color.rgb(245,247,250), muted=Color.rgb(166,173,184);

    public void onCreate(Bundle b){super.onCreate(b);id=getIntent().getLongExtra("evt_id",0);rec=getIntent().getStringExtra("recurrence_id");if(rec==null)rec="";fromWidget=getIntent().getBooleanExtra("from_widget",false);build();load();}
    void build(){
        ScrollView sv=new ScrollView(this); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(20),dp(14),dp(20),dp(30)); l.setBackgroundColor(bg);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView back=t("‹",34,false,text);back.setGravity(Gravity.CENTER);back.setMinWidth(dp(44));TextView h=t("Editar evento",26,true,text);top.addView(back);top.addView(h);l.addView(top);back.setOnClickListener(v->onBackPressed());
        calLabel=t("Cargando calendario…",13,true,Color.rgb(137,180,255));calLabel.setPadding(dp(4),0,0,dp(10));l.addView(calLabel);
        title=e("Título del evento"); title.setTextSize(20); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); l.addView(title,lp());
        all=new Switch(this);all.setText("Todo el día");all.setTextColor(text);all.setPadding(dp(4),dp(4),dp(4),dp(4));l.addView(all,lp());
        bs=action("Inicio");be=action("Fin");l.addView(bs,lp());l.addView(be,lp());
        loc=e("Ubicación");l.addView(loc,lp()); desc=e("Descripción");desc.setMinLines(4);desc.setGravity(Gravity.TOP);l.addView(desc,lp());
        save=action("✓  Guardar cambios en Synology Calendar");save.setTextColor(Color.WHITE);save.setBackgroundColor(Color.rgb(45,104,214));save.setGravity(Gravity.CENTER);save.setTypeface(Typeface.DEFAULT,Typeface.BOLD);l.addView(save,lp());
        status=t("Cargando…",13,false,muted);status.setPadding(dp(4),dp(7),dp(4),0);l.addView(status);sv.addView(l);setContentView(sv);
        bs.setOnClickListener(v->pick(true));be.setOnClickListener(v->pick(false));save.setOnClickListener(v->save());all.setOnCheckedChangeListener((v,c)->labels());
    }
    LinearLayout.LayoutParams lp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(10));return p;}
    TextView action(String s){TextView x=t(s,16,false,text);x.setPadding(dp(14),dp(16),dp(14),dp(16));x.setBackgroundColor(panel);return x;}
    void load(){
        EventItem cached=WidgetCache.find(this,id,rec);if(cached!=null){start=cached.start;end=cached.end;title.setText(cached.title);all.setChecked(cached.allDay);calendarColor=cached.calendarColor;setCalendar(cached.calendarName,cached.calendarColor);labels();}
        new Thread(()->{try{JSONObject o=new SynologyClient(this).getEvent(id,rec);runOnUiThread(()->apply(o));}catch(Exception e){runOnUiThread(()->status.setText("No se pudo cargar el evento: "+e.getMessage()));}}).start();
    }
    void apply(JSONObject o){title.setText(o.optString("summary",title.getText().toString()));start=o.optLong("dtstart",start);end=o.optLong("dtend",end);all.setChecked(o.optBoolean("is_all_day",all.isChecked()));desc.setText(o.optString("description",""));JSONObject li=o.optJSONObject("location_info");if(li!=null)loc.setText(li.optString("name",li.optString("address","")));EventItem cached=WidgetCache.find(this,id,rec);if(cached!=null)setCalendar(cached.calendarName,cached.calendarColor);labels();status.setText(rec.isBlank()?"Puedes modificar y guardar este evento.":"Estás editando solo esta aparición del evento recurrente.");}
    void setCalendar(String name,String color){calendarColor=color==null?"":color;int c=ColorUtil.readableCalendarColor(calendarColor,true,Color.rgb(137,180,255));calLabel.setText((name==null||name.isBlank()?"Calendario Synology":name));calLabel.setTextColor(c);}
    void labels(){if(start<=0||end<=0)return;SimpleDateFormat d=all.isChecked()?new SimpleDateFormat("EEE d MMM yyyy",new Locale("es","ES")):new SimpleDateFormat("EEE d MMM yyyy · HH:mm",new Locale("es","ES"));bs.setText("Inicio\n"+cap(d.format(new Date(start*1000L))));be.setText("Fin\n"+cap(d.format(new Date(end*1000L))));}
    void pick(boolean st){long val=st?start:end;Calendar c=Calendar.getInstance();if(val>0)c.setTimeInMillis(val*1000L);new DatePickerDialog(this,(v,y,m,d)->{c.set(y,m,d);if(all.isChecked()){c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);set(st,c);}else new TimePickerDialog(this,(tv,h,min)->{c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,min);c.set(Calendar.SECOND,0);set(st,c);},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void set(boolean st,Calendar c){if(st)start=c.getTimeInMillis()/1000L;else end=c.getTimeInMillis()/1000L;labels();}
    void save(){String ti=title.getText().toString().trim();if(ti.isEmpty()){status.setText("El evento necesita un título.");return;}if(end<=start){status.setText("La fecha u hora de fin debe ser posterior al inicio.");return;}save.setEnabled(false);status.setText("Guardando en Synology…");new Thread(()->{try{new SynologyClient(this).updateEvent(id,rec,ti,all.isChecked(),start,end,desc.getText().toString(),loc.getText().toString());WidgetUpdater.updateAll(this);runOnUiThread(()->{status.setText("✓ Cambios guardados correctamente.");save.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{status.setText("No se pudo guardar: "+e.getMessage());save.setEnabled(true);});}}).start();}
    @Override public void onBackPressed(){if(fromWidget){Intent i=new Intent(this,AgendaActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}else super.onBackPressed();}
    TextView t(String s,int z,boolean bo,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(z);if(bo)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setHintTextColor(muted);x.setTextColor(text);x.setTextSize(17);x.setPadding(dp(14),dp(13),dp(14),dp(13));x.setBackgroundColor(panel);return x;}int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}String cap(String s){return s==null||s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1);}
}
