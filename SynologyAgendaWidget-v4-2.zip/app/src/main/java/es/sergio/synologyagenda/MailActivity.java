package es.sergio.synologyagenda;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.widget.*;import java.util.List;
public class MailActivity extends Activity{
 boolean fromWidget;
 public void onCreate(Bundle b){super.onCreate(b);fromWidget=getIntent().getBooleanExtra("from_widget",false);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(36,32,36,40);l.setBackgroundColor(Color.rgb(20,20,20));TextView h=t(getIntent().getStringExtra("subject"),23,true);l.addView(h);l.addView(t(getIntent().getStringExtra("from"),17,true));l.addView(t(getIntent().getStringExtra("date"),14,false));l.addView(t("Pulsa el botón para abrir MailPlus y leer o gestionar el mensaje.",16,false));Button open=new Button(this);open.setText("Abrir MailPlus");open.setAllCaps(false);open.setOnClickListener(v->openMailPlus());l.addView(open);setContentView(l);}
 void openMailPlus(){
   final String pkg="com.synology.dsmail";
   try{
     Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
     if(i==null){
       Intent probe=new Intent(Intent.ACTION_MAIN);probe.addCategory(Intent.CATEGORY_LAUNCHER);probe.setPackage(pkg);
       List<android.content.pm.ResolveInfo> apps=getPackageManager().queryIntentActivities(probe,0);
       if(apps!=null&&!apps.isEmpty()){i=new Intent(probe);i.setClassName(pkg,apps.get(0).activityInfo.name);}
     }
     if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);startActivity(i);return;}
   }catch(Exception ignored){}
   try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id="+pkg)));}
   catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id="+pkg)));}
   Toast.makeText(this,"MailPlus no está disponible para abrir directamente. Te llevo a su ficha oficial.",Toast.LENGTH_LONG).show();
 }
 TextView t(String s,int z,boolean bold){TextView v=new TextView(this);v.setText(s==null?"":s);v.setTextColor(Color.WHITE);v.setTextSize(z);if(bold)v.setTypeface(null,1);v.setPadding(0,8,0,14);return v;}
}
