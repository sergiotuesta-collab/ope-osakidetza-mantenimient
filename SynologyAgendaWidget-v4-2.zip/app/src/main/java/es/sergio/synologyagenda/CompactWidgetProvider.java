package es.sergio.synologyagenda;
import android.appwidget.*;import android.content.*;
public class CompactWidgetProvider extends AppWidgetProvider {
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){async(c);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if("es.sergio.synologyagenda.REFRESH".equals(i.getAction()))async(c);}
 private void async(Context c){final PendingResult pr=goAsync();new Thread(()->{try{WidgetUpdater.updateAll(c);}finally{pr.finish();}}).start();}
}
