package es.sergio.synologyagenda;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.*;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;
import java.text.*;
import java.util.*;

public final class WidgetUpdater {
    private WidgetUpdater(){}
    public static void updateAll(Context c){
        try{
            long now=System.currentTimeMillis()/1000L;
            long start=EventFilter.todayStartSec();
            long end=now+(long)WidgetPrefs.days(c)*86400L;
            WidgetCache.save(c,new SynologyClient(c).events(start,end));
        }catch(Exception ignored){}
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        updateAgendaWidgets(c,m);
        updateCompactWidgets(c,m);
    }
    private static void updateAgendaWidgets(Context c,AppWidgetManager m){
        ComponentName cn=new ComponentName(c,AgendaWidgetProvider.class);
        for(int id:m.getAppWidgetIds(cn)) updateAgenda(c,m,id);
    }
    private static void updateCompactWidgets(Context c,AppWidgetManager m){
        ComponentName cn=new ComponentName(c,CompactWidgetProvider.class);
        for(int id:m.getAppWidgetIds(cn)) updateCompact(c,m,id);
    }
    public static void updateAgenda(Context c,AppWidgetManager m,int id){
        RemoteViews rv=new RemoteViews(c.getPackageName(),R.layout.widget_agenda_scroll);
        rv.setInt(R.id.widget_root,"setBackgroundResource",WidgetPrefs.amoled(c)?R.drawable.widget_bg_amoled:R.drawable.widget_bg);
        Date now=new Date();
        rv.setTextViewText(R.id.widget_day,"AGENDA");
        rv.setTextViewText(R.id.widget_date,new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","ES")).format(now));
        rv.setViewVisibility(R.id.widget_header,WidgetPrefs.showHeader(c)?View.VISIBLE:View.GONE);
        rv.setViewVisibility(R.id.widget_status,WidgetPrefs.showStatus(c)?View.VISIBLE:View.GONE);
        long up=WidgetCache.updated(c); rv.setTextViewText(R.id.widget_status,up>0?"Actualizado "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(up)):"Sin actualizar");
        Intent svc=new Intent(c,AgendaRemoteViewsService.class); svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id); svc.setData(Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))); rv.setRemoteAdapter(R.id.widget_list,svc);
        Intent open=new Intent(c,EventDetailActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP); PendingIntent tpl=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_MUTABLE); rv.setPendingIntentTemplate(R.id.widget_list,tpl);
        Intent ri=new Intent(c,AgendaWidgetProvider.class).setAction("es.sergio.synologyagenda.REFRESH"); PendingIntent rp=PendingIntent.getBroadcast(c,1000+id,ri,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); rv.setOnClickPendingIntent(R.id.widget_refresh,rp);
        Intent si=new Intent(c,MainActivity.class);si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent sp=PendingIntent.getActivity(c,5000+id,si,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);rv.setOnClickPendingIntent(R.id.widget_settings,sp);
        Intent ai=new Intent(c,AgendaActivity.class);ai.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent ap=PendingIntent.getActivity(c,2000+id,ai,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); rv.setOnClickPendingIntent(R.id.widget_header,ap);
        rv.setEmptyView(R.id.widget_list,R.id.widget_empty);
        m.updateAppWidget(id,rv); m.notifyAppWidgetViewDataChanged(id,R.id.widget_list);
    }
    public static void updateCompact(Context c,AppWidgetManager m,int id){
        RemoteViews rv=new RemoteViews(c.getPackageName(),R.layout.widget_compact);
        rv.setInt(R.id.compact_root,"setBackgroundResource",WidgetPrefs.amoled(c)?R.drawable.widget_bg_amoled:R.drawable.widget_bg);
        List<EventItem> ev=WidgetCache.load(c); long now=System.currentTimeMillis()/1000L; EventItem pick=null;
        for(EventItem e:ev){if(EventFilter.include(c,e)){pick=e;break;}}
        if(pick==null){rv.setTextViewText(R.id.compact_title,"Sin próximos eventos");rv.setTextViewText(R.id.compact_time,"");}
        else { Date d=new Date(pick.start*1000L); Calendar t=Calendar.getInstance(),ec=Calendar.getInstance();ec.setTime(d); String when=pick.allDay?"Todo el día":new SimpleDateFormat("HH:mm",Locale.getDefault()).format(d); if(!sameDay(t,ec)) when=new SimpleDateFormat("EEE d MMM",new Locale("es","ES")).format(d)+" · "+when; rv.setTextViewText(R.id.compact_title,pick.title);rv.setTextViewText(R.id.compact_time,when);int cc=ColorUtil.readableCalendarColor(pick.calendarColor,true,android.graphics.Color.rgb(245,247,250));rv.setTextColor(R.id.compact_title,cc); }
        rv.setTextViewTextSize(R.id.compact_title,android.util.TypedValue.COMPLEX_UNIT_SP,WidgetPrefs.textSize(c));
        Intent ri=new Intent(c,CompactWidgetProvider.class).setAction("es.sergio.synologyagenda.REFRESH"); PendingIntent rp=PendingIntent.getBroadcast(c,3000+id,ri,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); rv.setOnClickPendingIntent(R.id.compact_refresh,rp);
        Intent si=new Intent(c,MainActivity.class);si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent sp=PendingIntent.getActivity(c,6000+id,si,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);rv.setOnClickPendingIntent(R.id.compact_settings,sp);
        PendingIntent ap=PendingIntent.getActivity(c,4000+id,new Intent(c,AgendaActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); rv.setOnClickPendingIntent(R.id.compact_root,ap);
        m.updateAppWidget(id,rv);
    }
    private static long dayStartSec(){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis()/1000L;}
    private static boolean sameDay(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}
}
