package es.sergio.synologyagenda;

import android.content.Context;
import java.util.*;

public final class EventFilter {
    private EventFilter(){}
    public static long todayStartSec(){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis()/1000L;}
    public static boolean include(Context c, EventItem e){
        long now=System.currentTimeMillis()/1000L;
        long today=todayStartSec();
        // Anything that ended before today is always old. This fixes old all-day events lingering in the agenda.
        if(e.end>0 && e.end<=today) return false;
        // Events starting before today but still spanning today are allowed.
        if(e.start<today && e.end<=today) return false;
        if(WidgetPrefs.hidePast(c) && !e.allDay && e.end>0 && e.end<=now) return false;
        return true;
    }
    public static List<EventItem> upcoming(Context c,List<EventItem> source){
        List<EventItem> out=new ArrayList<>(); for(EventItem e:source) if(include(c,e)) out.add(e); return out;
    }
}
