package es.sergio.synologyagenda;

public class EventItem {
    public final long evtId;
    public final String recurrenceId;
    public final String title;
    public final long start;
    public final long end;
    public final boolean allDay;
    public final String calId;
    public final String originalCalId;
    public final String davEtag;
    public final String calendarName;
    public final String calendarColor;

    public EventItem(long evtId, String recurrenceId, String title, long start, long end, boolean allDay,
                     String calId, String originalCalId, String davEtag) {
        this(evtId, recurrenceId, title, start, end, allDay, calId, originalCalId, davEtag, "", "");
    }

    public EventItem(long evtId, String recurrenceId, String title, long start, long end, boolean allDay,
                     String calId, String originalCalId, String davEtag, String calendarName, String calendarColor) {
        this.evtId = evtId;
        this.recurrenceId = recurrenceId == null ? "" : recurrenceId;
        this.title = title == null || title.isBlank() ? "(Sin título)" : title;
        this.start = start;
        this.end = end;
        this.allDay = allDay;
        this.calId = calId == null ? "" : calId;
        this.originalCalId = originalCalId == null ? "" : originalCalId;
        this.davEtag = davEtag == null ? "" : davEtag;
        this.calendarName = calendarName == null ? "" : calendarName;
        this.calendarColor = calendarColor == null ? "" : calendarColor;
    }

    public String stableKey() { return evtId + "|" + recurrenceId; }
}
