# Agenda Synology v2

Widget Android para Synology Calendar mediante Web API + QuickConnect.

## Novedades v2
- Agenda desplazable con scroll real.
- Agrupación por días: HOY, MAÑANA y fechas siguientes.
- Oculta por defecto los eventos ya pasados de hoy.
- Segundo widget compacto de próximo evento.
- Tamaño de texto configurable: 14/16/18/20 sp.
- Densidad de filas: compacta/normal/cómoda.
- Horizonte configurable: 7/14/30/60 días.
- Cabecera y estado de actualización opcionales.
- Fondo negro AMOLED opcional.
- Ajuste al tamaño del widget.
- Contraseña almacenada cifrada con Android Keystore.
- Login enviado por POST (la contraseña ya no se coloca en la URL).

Inspirado en las mejores ideas de Business Calendar 2, DigiCal, aCalendar y Home Agenda, pero conectado directamente al Synology Calendar del usuario.
