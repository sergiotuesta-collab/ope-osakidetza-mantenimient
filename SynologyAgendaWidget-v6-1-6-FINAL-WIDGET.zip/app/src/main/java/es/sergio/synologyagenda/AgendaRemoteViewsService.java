package es.sergio.synologyagenda;

import android.content.*;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import java.text.*;
import java.util.*;

public class AgendaRemoteViewsService extends RemoteViewsService {
    public RemoteViewsFactory onGetViewFactory(Intent i){return new F(getApplicationContext());}
    static class Row {boolean header;EventItem e;String t,w;Row(String h){header=true;t=h;}Row(EventItem e,String w){this.e=e;this.w=w;this.t=e.title;}}
    static class F implements RemoteViewsFactory {
        Context c; List<Row> r=new ArrayList<>(); F(Context c){this.c=c;}
        public void onCreate(){reload();} public void onDataSetChanged(){reload();}
        void reload(){
            r.clear(); List<EventItem> es=EventFilter.upcoming(c,WidgetCache.load(c)); String last="";
            SimpleDateFormat kf=new SimpleDateFormat("yyyyMMdd",Locale.US),df=new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","ES")),tf=new SimpleDateFormat("HH:mm",Locale.getDefault());
            Calendar today=Calendar.getInstance();
            for(EventItem e:es){Date d=new Date(e.start*1000L);String k=kf.format(d);if(WidgetPrefs.showDayHeaders(c)&&!k.equals(last)){Calendar ec=Calendar.getInstance();ec.setTime(d);String lab=df.format(d);if(same(today,ec))lab="HOY · "+lab;else{Calendar tm=(Calendar)today.clone();tm.add(Calendar.DAY_OF_YEAR,1);if(same(tm,ec))lab="MAÑANA · "+lab;}r.add(new Row(lab));last=k;}r.add(new Row(e,e.allDay?"Todo el día":tf.format(d)));}
        }
        boolean same(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}
        public void onDestroy(){r.clear();} public int getCount(){return r.size();}
        public RemoteViews getViewAt(int p){
            if(p<0||p>=r.size())return null;Row x=r.get(p);RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_agenda_row);int sz=WidgetPrefs.textSize(c);
            if(x.header){v.setViewVisibility(R.id.row_header,View.VISIBLE);v.setViewVisibility(R.id.row_event,View.GONE);v.setTextViewText(R.id.row_header,x.t);}
            else{
                v.setViewVisibility(R.id.row_header,View.GONE);v.setViewVisibility(R.id.row_event,View.VISIBLE);v.setTextViewText(R.id.row_time,x.w);v.setTextViewText(R.id.row_title,x.t);v.setTextViewTextSize(R.id.row_title,android.util.TypedValue.COMPLEX_UNIT_SP,sz);
                int cc=ColorUtil.readableCalendarColor(x.e.calendarColor,true,Color.rgb(235,238,242));v.setTextColor(R.id.row_title,cc);v.setTextColor(R.id.row_dot,cc);v.setTextViewText(R.id.row_dot,"●");
                int mode=WidgetPrefs.detailMode(c); String ds=x.e.description==null?"":x.e.description.trim(); String lc=x.e.location==null?"":x.e.location.trim();
                v.setTextViewText(R.id.row_desc,ds);v.setTextViewText(R.id.row_loc,lc.isBlank()?"":"📍 "+lc);
                v.setViewVisibility(R.id.row_desc,(mode>=1&&!ds.isBlank())?View.VISIBLE:View.GONE);v.setViewVisibility(R.id.row_loc,(mode>=2&&!lc.isBlank())?View.VISIBLE:View.GONE);
                WidgetAttachmentCache.Summary at=WidgetAttachmentCache.get(c,x.e.evtId);
                if(at.count>0){String label="📎 "+at.count+" archivo"+(at.count==1?"":"s");if(!at.firstName.isBlank())label+=" · "+at.firstName;v.setTextViewText(R.id.row_attach,label);v.setViewVisibility(R.id.row_attach,View.VISIBLE);}else{v.setTextViewText(R.id.row_attach,"");v.setViewVisibility(R.id.row_attach,View.GONE);}
                int lines=mode>=2?3:mode==1?2:1;v.setInt(R.id.row_desc,"setMaxLines",lines);
                int py=WidgetPrefs.density(c)==0?2:WidgetPrefs.density(c)==2?8:5;v.setViewPadding(R.id.row_event,0,dp(c,py),0,dp(c,py));
                Intent f=new Intent();f.putExtra("evt_id",x.e.evtId);f.putExtra("recurrence_id",x.e.recurrenceId);f.putExtra("from_widget",true);v.setOnClickFillInIntent(R.id.row_event,f);
            }
            return v;
        }
        static int dp(Context c,int x){return(int)(x*c.getResources().getDisplayMetrics().density+.5f);} public RemoteViews getLoadingView(){return null;}public int getViewTypeCount(){return 1;}public long getItemId(int p){return p;}public boolean hasStableIds(){return false;}
    }
}
