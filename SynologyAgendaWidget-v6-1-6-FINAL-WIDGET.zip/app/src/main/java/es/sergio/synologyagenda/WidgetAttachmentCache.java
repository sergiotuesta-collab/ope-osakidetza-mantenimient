package es.sergio.synologyagenda;

import android.content.Context;
import org.json.JSONObject;
import java.util.*;

public final class WidgetAttachmentCache {
    private WidgetAttachmentCache(){}
    public static final class Summary {
        public final int count; public final long totalBytes; public final String firstName;
        Summary(int c,long b,String n){count=c;totalBytes=b;firstName=n==null?"":n;}
    }
    public static void save(Context c, Map<Long,List<SynologyClient.NasFile>> map){
        JSONObject root=new JSONObject();
        try{
            for(Map.Entry<Long,List<SynologyClient.NasFile>> en:map.entrySet()){
                List<SynologyClient.NasFile> fs=en.getValue(); if(fs==null||fs.isEmpty())continue;
                long total=0; for(SynologyClient.NasFile f:fs)total+=Math.max(0,f.size);
                JSONObject o=new JSONObject();o.put("count",fs.size());o.put("bytes",total);o.put("first",fs.get(0).name);root.put(Long.toString(en.getKey()),o);
            }
        }catch(Exception ignored){}
        c.getSharedPreferences("widget_attachment_cache",Context.MODE_PRIVATE).edit().putString("items",root.toString()).putLong("updated",System.currentTimeMillis()).apply();
    }
    public static Summary get(Context c,long evtId){
        try{
            String raw=c.getSharedPreferences("widget_attachment_cache",Context.MODE_PRIVATE).getString("items","{}");
            JSONObject o=new JSONObject(raw).optJSONObject(Long.toString(evtId));
            if(o==null)return new Summary(0,0,"");
            return new Summary(o.optInt("count",0),o.optLong("bytes",0),o.optString("first",""));
        }catch(Exception e){return new Summary(0,0,"");}
    }
}
