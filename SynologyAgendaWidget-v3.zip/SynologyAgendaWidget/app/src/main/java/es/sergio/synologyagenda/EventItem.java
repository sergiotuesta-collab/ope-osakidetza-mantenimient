package es.sergio.synologyagenda;

public class EventItem {
    public final String title;
    public final long start;
    public final long end;
    public final boolean allDay;

    public EventItem(String title, long start, long end, boolean allDay) {
        this.title = title;
        this.start = start;
        this.end = end;
        this.allDay = allDay;
    }
}
