package es.sergio.synologyagenda;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class SynologyClient {
    private final Context ctx;
    private final String base, user, password;
    private String sid, token, did;

    public SynologyClient(Context c) {
        ctx=c.getApplicationContext();
        android.content.SharedPreferences p=c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        base=normalize(p.getString("server", "https://nastuesta.fr3.quickconnect.to"));
        user=p.getString("user", "sergio");
        password=CryptoStore.get(c,"password"); did=CryptoStore.get(c,"did");
        sid=p.getString("sid", null); token=p.getString("token", null);
    }
    private static String normalize(String s){ s=s.trim(); if(!s.startsWith("https://")) s="https://"+s; while(s.endsWith("/")) s=s.substring(0,s.length()-1); return s; }

    public JSONObject login(String otp, boolean firstTrust) throws Exception {
        Map<String,String> q=new LinkedHashMap<>();
        q.put("api","SYNO.API.Auth"); q.put("version","6"); q.put("method","login"); q.put("account",user); q.put("passwd",password);
        q.put("session","Calendar"); q.put("format","sid"); q.put("enable_syno_token","yes");
        if(firstTrust && otp!=null && !otp.isBlank()) { q.put("otp_code",otp.trim()); q.put("enable_device_token","yes"); q.put("device_name","Agenda Synology S25"); }
        else if(did!=null && !did.isBlank()) { q.put("device_name","Agenda Synology S25"); q.put("device_id",did); }
        else if(otp!=null && !otp.isBlank()) q.put("otp_code",otp.trim());
        JSONObject r=postForm(base+"/webapi/entry.cgi", q, null);
        if(r.optBoolean("success")) {
            JSONObject d=r.getJSONObject("data"); sid=d.optString("sid",""); token=d.optString("synotoken","");
            String newDid=d.optString("did",""); if(!newDid.isBlank()){ did=newDid; CryptoStore.put(ctx,"did",did); }
            ctx.getSharedPreferences("cfg",Context.MODE_PRIVATE).edit().putString("sid",sid).putString("token",token).apply();
        }
        return r;
    }

    public List<EventItem> events(long startSec, long endSec) throws Exception {
        if(sid==null || sid.isBlank()) {
            JSONObject lr=login(null,false); if(!lr.optBoolean("success")) throw new IOException("Necesita volver a iniciar sesión");
        }
        try { return eventsOnce(startSec,endSec); }
        catch(AuthException ex) {
            JSONObject lr=login(null,false); if(!lr.optBoolean("success")) throw new IOException("Sesión caducada: abre la app para autenticarte");
            return eventsOnce(startSec,endSec);
        }
    }

    private List<EventItem> eventsOnce(long startSec,long endSec) throws Exception {
        Map<String,String> p=new LinkedHashMap<>();
        p.put("api","SYNO.Cal.Event"); p.put("version","5"); p.put("method","list");
        p.put("start",Long.toString(startSec)); p.put("end",Long.toString(endSec)); p.put("limit","100"); p.put("_sid",sid);
        if(token!=null&&!token.isBlank()) p.put("SynoToken",token);
        JSONObject r=postForm(base+"/webapi/entry.cgi",p,token);
        if(!r.optBoolean("success")) {
            int code=r.optJSONObject("error")!=null?r.optJSONObject("error").optInt("code",0):0;
            if(code==105||code==106||code==107) throw new AuthException();
            throw new IOException("Synology API error "+code);
        }
        JSONArray list=r.getJSONObject("data").optJSONArray("list"); List<EventItem> out=new ArrayList<>();
        if(list!=null) for(int i=0;i<list.length();i++){
            JSONObject e=list.getJSONObject(i); String title=e.optString("summary","(Sin título)"); long st=e.optLong("dtstart",0); long en=e.optLong("dtend",st); boolean all=e.optBoolean("is_all_day",false);
            if(st>0) out.add(new EventItem(title,st,en,all));
        }
        out.sort(Comparator.comparingLong(x->x.start)); return out;
    }

    private static class AuthException extends Exception {}
    private static String encode(Map<String,String> map) throws Exception { StringBuilder sb=new StringBuilder(); for(Map.Entry<String,String>e:map.entrySet()){ if(sb.length()>0)sb.append('&'); sb.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8")); } return sb.toString(); }
    private static JSONObject getJson(String url,String token) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json"); if(token!=null)c.setRequestProperty("X-SYNO-TOKEN",token); return read(c); }
    private static JSONObject postForm(String url,Map<String,String> params,String token) throws Exception { byte[] body=encode(params).getBytes(StandardCharsets.UTF_8); HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(15000); c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8"); c.setRequestProperty("Accept","application/json"); if(token!=null&&!token.isBlank()) c.setRequestProperty("X-SYNO-TOKEN",token); c.getOutputStream().write(body); return read(c); }
    private static JSONObject read(HttpURLConnection c) throws Exception { int code=c.getResponseCode(); InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream(); if(in==null) throw new IOException("HTTP "+code); String text; try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){ StringBuilder sb=new StringBuilder(); String l; while((l=br.readLine())!=null)sb.append(l); text=sb.toString(); } return new JSONObject(text); }
}
