package es.sergio.synologyagenda;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public final class WidgetCache {
    private WidgetCache() {}
    public static void save(Context c, List<EventItem> events){
        JSONArray a=new JSONArray();
        try{
            for(EventItem e:events){
                JSONObject o=new JSONObject();
                o.put("title",e.title);o.put("start",e.start);o.put("end",e.end);o.put("allDay",e.allDay);a.put(o);
            }
        }catch(Exception ignored){}
        c.getSharedPreferences("widget_cache",Context.MODE_PRIVATE).edit().putString("events",a.toString()).putLong("updated",System.currentTimeMillis()).apply();
    }
    public static List<EventItem> load(Context c){
        List<EventItem> out=new ArrayList<>();
        String raw=c.getSharedPreferences("widget_cache",Context.MODE_PRIVATE).getString("events","[]");
        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                out.add(new EventItem(o.optString("title","(Sin título)"),o.optLong("start"),o.optLong("end"),o.optBoolean("allDay")));
            }
        }catch(Exception ignored){}
        return out;
    }
    public static long updated(Context c){ return c.getSharedPreferences("widget_cache",Context.MODE_PRIVATE).getLong("updated",0); }
}
