package es.sergio.synologyagenda;

import android.content.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class AgendaRemoteViewsService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent intent){ return new Factory(getApplicationContext()); }

    static class Row {
        final boolean header; final String title; final String when;
        Row(boolean h,String t,String w){header=h;title=t;when=w;}
    }

    static class Factory implements RemoteViewsFactory {
        private final Context c; private final List<Row> rows=new ArrayList<>();
        Factory(Context c){this.c=c;}
        @Override public void onCreate(){ reload(); }
        @Override public void onDataSetChanged(){ reload(); }
        private void reload(){
            rows.clear();
            List<EventItem> events=WidgetCache.load(c);
            long now=System.currentTimeMillis()/1000L;
            Calendar today=Calendar.getInstance(); today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);today.set(Calendar.SECOND,0);today.set(Calendar.MILLISECOND,0);
            long todayStart=today.getTimeInMillis()/1000L;
            String lastDay="";
            DateFormat tf=new SimpleDateFormat("HH:mm",Locale.getDefault());
            SimpleDateFormat keyFmt=new SimpleDateFormat("yyyyMMdd",Locale.US);
            SimpleDateFormat dayFmt=new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","ES"));
            for(EventItem e:events){
                if(e.start<todayStart) continue;
                if(WidgetPrefs.hidePast(c) && !e.allDay && e.end<now) continue;
                Date d=new Date(e.start*1000L); String key=keyFmt.format(d);
                if(WidgetPrefs.showDayHeaders(c) && !key.equals(lastDay)){
                    String label=dayFmt.format(d);
                    Calendar ec=Calendar.getInstance();ec.setTime(d);
                    if(sameDay(today,ec)) label="HOY · "+label;
                    else { Calendar tom=(Calendar)today.clone(); tom.add(Calendar.DAY_OF_YEAR,1); if(sameDay(tom,ec)) label="MAÑANA · "+label; }
                    rows.add(new Row(true,label,"")); lastDay=key;
                }
                String when=e.allDay?"Todo el día":tf.format(d);
                rows.add(new Row(false,e.title,when));
            }
            if(rows.isEmpty()) rows.add(new Row(false,"Sin próximos eventos",""));
        }
        private boolean sameDay(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}
        @Override public void onDestroy(){rows.clear();}
        @Override public int getCount(){return rows.size();}
        @Override public RemoteViews getViewAt(int pos){
            if(pos<0||pos>=rows.size()) return null; Row r=rows.get(pos);
            RemoteViews rv=new RemoteViews(c.getPackageName(),R.layout.widget_agenda_row);
            int size=WidgetPrefs.textSize(c); int density=WidgetPrefs.density(c);
            if(r.header){
                rv.setViewVisibility(R.id.row_header,android.view.View.VISIBLE);rv.setViewVisibility(R.id.row_event,android.view.View.GONE);
                rv.setTextViewText(R.id.row_header,r.title); rv.setTextViewTextSize(R.id.row_header,android.util.TypedValue.COMPLEX_UNIT_SP,Math.max(11,size-3));
            } else {
                rv.setViewVisibility(R.id.row_header,android.view.View.GONE);rv.setViewVisibility(R.id.row_event,android.view.View.VISIBLE);
                rv.setTextViewText(R.id.row_time,r.when);rv.setTextViewText(R.id.row_title,r.title);
                rv.setTextViewTextSize(R.id.row_time,android.util.TypedValue.COMPLEX_UNIT_SP,Math.max(11,size-3));
                rv.setTextViewTextSize(R.id.row_title,android.util.TypedValue.COMPLEX_UNIT_SP,size);
                int py=density==0?2:(density==2?9:5); rv.setViewPadding(R.id.row_event,0,py,0,py);
                Intent fill=new Intent(); fill.putExtra("title",r.title); rv.setOnClickFillInIntent(R.id.row_event,fill);
            }
            return rv;
        }
        @Override public RemoteViews getLoadingView(){return null;}
        @Override public int getViewTypeCount(){return 1;}
        @Override public long getItemId(int position){return position;}
        @Override public boolean hasStableIds(){return false;}
    }
}
