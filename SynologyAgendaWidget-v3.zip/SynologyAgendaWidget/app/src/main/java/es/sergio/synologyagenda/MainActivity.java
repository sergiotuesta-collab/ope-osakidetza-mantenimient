package es.sergio.synologyagenda;

import android.app.*;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    EditText server,user,password,otp; TextView status; Button connect,refresh,saveWidget;
    Spinner daysSpinner,textSpinner,densitySpinner; Switch hidePast,dayHeaders,showHeader,showStatus,amoled;
    final int[] dayValues={7,14,30,60}; final int[] textValues={14,16,18,20};
    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        server=findViewById(R.id.server);user=findViewById(R.id.user);password=findViewById(R.id.password);otp=findViewById(R.id.otp);status=findViewById(R.id.status);connect=findViewById(R.id.connect);refresh=findViewById(R.id.refresh);saveWidget=findViewById(R.id.save_widget);
        daysSpinner=findViewById(R.id.days_spinner);textSpinner=findViewById(R.id.text_spinner);densitySpinner=findViewById(R.id.density_spinner);hidePast=findViewById(R.id.hide_past);dayHeaders=findViewById(R.id.day_headers);showHeader=findViewById(R.id.show_header);showStatus=findViewById(R.id.show_status);amoled=findViewById(R.id.amoled);
        android.content.SharedPreferences p=getSharedPreferences("cfg",MODE_PRIVATE); server.setText(p.getString("server","https://nastuesta.fr3.quickconnect.to")); user.setText(p.getString("user","sergio")); if(CryptoStore.get(this,"password")!=null) password.setHint("Contraseña guardada de forma cifrada");
        setupWidgetSettings();
        connect.setOnClickListener(v->connect());
        refresh.setOnClickListener(v->refreshWidgets("Actualizando…","Widgets actualizados."));
        saveWidget.setOnClickListener(v->saveWidgetSettings());
    }
    private void setupWidgetSettings(){
        ArrayAdapter<String> days=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"7 días","14 días","30 días","60 días"});daysSpinner.setAdapter(days);
        ArrayAdapter<String> texts=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Pequeño (14)","Normal (16)","Grande (18)","Muy grande (20)"});textSpinner.setAdapter(texts);
        ArrayAdapter<String> dens=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Compacta","Normal","Cómoda"});densitySpinner.setAdapter(dens);
        android.content.SharedPreferences p=getSharedPreferences("widget_prefs",MODE_PRIVATE);
        daysSpinner.setSelection(indexOf(dayValues,p.getInt("days",30)));textSpinner.setSelection(indexOf(textValues,p.getInt("text_size",16)));densitySpinner.setSelection(p.getInt("density",1));
        hidePast.setChecked(p.getBoolean("hide_past",true));dayHeaders.setChecked(p.getBoolean("day_headers",true));showHeader.setChecked(p.getBoolean("show_header",true));showStatus.setChecked(p.getBoolean("show_status",true));amoled.setChecked(p.getBoolean("amoled",false));
    }
    private int indexOf(int[] a,int v){for(int i=0;i<a.length;i++)if(a[i]==v)return i;return 0;}
    private void saveWidgetSettings(){
        getSharedPreferences("widget_prefs",MODE_PRIVATE).edit().putInt("days",dayValues[daysSpinner.getSelectedItemPosition()]).putInt("text_size",textValues[textSpinner.getSelectedItemPosition()]).putInt("density",densitySpinner.getSelectedItemPosition()).putBoolean("hide_past",hidePast.isChecked()).putBoolean("day_headers",dayHeaders.isChecked()).putBoolean("show_header",showHeader.isChecked()).putBoolean("show_status",showStatus.isChecked()).putBoolean("amoled",amoled.isChecked()).apply();
        refreshWidgets("Aplicando ajustes…","Ajustes guardados y widgets actualizados.");
    }
    private void refreshWidgets(String start,String done){status.setText(start);new Thread(()->{WidgetUpdater.updateAll(this);runOnUiThread(()->status.setText(done));}).start();}
    private void connect(){ String s=server.getText().toString().trim(),u=user.getText().toString().trim(),pw=password.getText().toString(); if(s.isEmpty()||u.isEmpty()){status.setText("Falta servidor o usuario.");return;} try{getSharedPreferences("cfg",MODE_PRIVATE).edit().putString("server",s).putString("user",u).apply(); if(!pw.isEmpty())CryptoStore.put(this,"password",pw); else if(CryptoStore.get(this,"password")==null){status.setText("Introduce la contraseña.");return;}}catch(Exception e){status.setText("No se pudo guardar la contraseña de forma segura.");return;}
        connect.setEnabled(false); status.setText("Conectando con Synology…"); new Thread(()->{try{JSONObject r=new SynologyClient(this).login(otp.getText().toString(),true); if(r.optBoolean("success")){WidgetUpdater.updateAll(this);runOnUiThread(()->{status.setText("Conectado. Widgets listos.");connect.setEnabled(true);otp.setText("");password.setText("");});}else{int code=r.optJSONObject("error")!=null?r.optJSONObject("error").optInt("code",0):0;runOnUiThread(()->{status.setText("Synology rechazó el inicio de sesión (código "+code+"). Si tienes 2FA, introduce el OTP actual.");connect.setEnabled(true);});}}catch(Exception e){runOnUiThread(()->{status.setText("Error: "+e.getMessage());connect.setEnabled(true);});}}).start(); }
}
