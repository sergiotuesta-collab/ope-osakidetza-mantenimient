package es.sergio.synologyagenda; public class MailItem{public final String from,subject,date;public MailItem(String f,String s,String d){from=f;subject=s;date=d;}}
