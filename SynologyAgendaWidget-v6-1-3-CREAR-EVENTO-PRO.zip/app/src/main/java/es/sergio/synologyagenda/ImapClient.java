package es.sergio.synologyagenda;

import android.content.Context;
import javax.net.ssl.*;
import java.io.*;
import java.nio.charset.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class ImapClient {
    final Context c;
    public ImapClient(Context c){this.c=c;}

    private String q(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";}

    public int unreadCount()throws Exception{
        Session ss=open();
        try{
            List<String> sr=cmd(ss.out,ss.in,"U1 UID SEARCH UNSEEN","U1");
            int count=0;
            for(String l:sr)if(l.startsWith("* SEARCH")){
                String x=l.substring(8).trim();
                if(!x.isBlank())for(String part:x.split(" +"))if(!part.isBlank())count++;
            }
            return count;
        } finally { close(ss); }
    }

    public List<MailItem> latest(int limit)throws Exception{
        Session ss=open();
        try{
            List<String> sr=cmd(ss.out,ss.in,"A3 UID SEARCH ALL","A3");
            List<Long> ids=new ArrayList<>();
            for(String l:sr)if(l.startsWith("* SEARCH")){
                for(String p:l.substring(8).trim().split(" +"))try{ids.add(Long.parseLong(p));}catch(Exception ignored){}
            }
            Collections.reverse(ids);
            List<MailItem> res=new ArrayList<>();
            int n=Math.min(limit,ids.size());
            for(int i=0;i<n;i++){
                long uid=ids.get(i);String tag="F"+i;
                List<String> lines=cmd(ss.out,ss.in,tag+" UID FETCH "+uid+" (FLAGS BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])",tag);
                boolean unread=true;
                for(String l:lines)if(l.contains("FLAGS")&&l.contains("\\Seen"))unread=false;
                Map<String,String> h=headers(lines);
                String rawFrom=decodeWords(h.getOrDefault("from",""));
                String from=cleanFrom(rawFrom);
                String sub=decodeWords(h.getOrDefault("subject","(Sin asunto)"));
                String date=prettyDate(h.getOrDefault("date",""));
                res.add(new MailItem(uid,from,sub,date,unread));
            }
            return res;
        } finally { close(ss); }
    }

    public String deleteMessage(long uid)throws Exception{
        if(uid<=0)throw new Exception("Mensaje no válido");
        Session ss=open();
        try{
            String trash=findTrashMailbox(ss);
            if(!trash.isBlank()){
                try{
                    cmd(ss.out,ss.in,"D2 UID MOVE "+uid+" "+q(trash),"D2");
                    return "Papelera";
                }catch(Exception moveError){
                    try{
                        cmd(ss.out,ss.in,"D3 UID COPY "+uid+" "+q(trash),"D3");
                        cmd(ss.out,ss.in,"D4 UID STORE "+uid+" +FLAGS.SILENT (\\Deleted)","D4");
                        expungeUid(ss,uid,"D5");
                        return "Papelera";
                    }catch(Exception copyError){
                        // Si el servidor no permite MOVE/COPY a Papelera, seguimos con borrado IMAP estándar.
                    }
                }
            }
            cmd(ss.out,ss.in,"D6 UID STORE "+uid+" +FLAGS.SILENT (\\Deleted)","D6");
            expungeUid(ss,uid,"D7");
            return "Eliminado";
        } finally { close(ss); }
    }

    private void expungeUid(Session ss,long uid,String tag)throws Exception{
        try{cmd(ss.out,ss.in,tag+" UID EXPUNGE "+uid,tag);}
        catch(Exception e){String t=tag+"X";cmd(ss.out,ss.in,t+" EXPUNGE",t);}
    }

    private String findTrashMailbox(Session ss){
        try{
            List<String> lines=cmd(ss.out,ss.in,"D1 LIST \"\" \"*\"","D1");
            String common="";
            for(String line:lines){
                if(line==null||!line.toUpperCase(Locale.ROOT).startsWith("* LIST"))continue;
                String box=mailboxFromListLine(line);
                if(box.isBlank())continue;
                String low=box.toLowerCase(Locale.ROOT);
                if(line.toLowerCase(Locale.ROOT).contains("\\trash"))return box;
                if(common.isBlank()&&(low.equals("trash")||low.equals("papelera")||low.endsWith("/trash")||low.endsWith("/papelera")||low.contains("deleted")))common=box;
            }
            return common;
        }catch(Exception e){return "";}
    }

    private String mailboxFromListLine(String line){
        int end=line.lastIndexOf('\"');
        if(end<0)return "";
        int start=end-1;
        while(start>=0){
            if(line.charAt(start)=='\"'&&(start==0||line.charAt(start-1)!='\\'))break;
            start--;
        }
        if(start<0||start>=end)return "";
        return line.substring(start+1,end).replace("\\\"","\"").replace("\\\\","\\");
    }

    public MailMessage message(long uid)throws Exception{
        if(uid<=0)throw new Exception("Mensaje no válido");
        Session ss=open();
        try{
            String raw=fetchRawMessage(ss,uid);
            if(raw.isBlank())throw new Exception("No se pudo leer el contenido del mensaje");
            ParsedPart p=parsePart(raw);
            Map<String,String> h=parseHeaderBlock(raw);
            String rawFrom=decodeWords(h.getOrDefault("from",""));
            String from=cleanFrom(rawFrom);
            String fromAddress=extractAddress(rawFrom);
            String to=decodeWords(h.getOrDefault("to",""));
            String subject=decodeWords(h.getOrDefault("subject","(Sin asunto)"));
            String date=prettyDate(h.getOrDefault("date",""));
            try{cmd(ss.out,ss.in,"M2 UID STORE "+uid+" +FLAGS.SILENT (\\Seen)","M2");}catch(Exception ignored){}
            return new MailMessage(uid,from,fromAddress,to,subject,date,p.body,p.html);
        } finally { close(ss); }
    }


    private String fetchRawMessage(Session ss,long uid)throws Exception{
        String[] items={"BODY.PEEK[]","RFC822.PEEK","RFC822"};
        int n=0;
        for(String item:items){
            String tag="MB"+(++n);
            try{
                String raw=fetchLiteral(ss,tag,tag+" UID FETCH "+uid+" ("+item+")");
                if(raw!=null&&!raw.isBlank())return raw;
            }catch(Exception ignored){}
        }
        String head="",body="";
        try{head=fetchLiteral(ss,"MH1","MH1 UID FETCH "+uid+" (BODY.PEEK[HEADER])");}catch(Exception ignored){}
        try{body=fetchLiteral(ss,"MT1","MT1 UID FETCH "+uid+" (BODY.PEEK[TEXT])");}catch(Exception ignored){}
        if(!head.isBlank()||!body.isBlank())return head+"\r\n\r\n"+body;
        return "";
    }

    private String fetchLiteral(Session ss,String tag,String command)throws Exception{
        ss.out.write((command+"\r\n").getBytes(StandardCharsets.UTF_8));
        ss.out.flush();
        ByteArrayOutputStream literal=new ByteArrayOutputStream();
        Pattern sizePattern=Pattern.compile("\\{(\\d+)\\+?\\}$");
        while(true){
            String line=readLine(ss.in);
            if(line==null)throw new EOFException("Respuesta IMAP incompleta");
            Matcher m=sizePattern.matcher(line);
            if(m.find()){
                int size=Integer.parseInt(m.group(1));
                byte[] data=ss.in.readNBytes(size);
                if(data.length!=size)throw new EOFException("Respuesta IMAP incompleta");
                literal.write(data);
                continue;
            }
            if(line.startsWith(tag+" ")){
                if(!line.toUpperCase(Locale.ROOT).contains(" OK"))throw new IOException(line);
                break;
            }
        }
        byte[] data=literal.toByteArray();
        if(data.length==0)return "";
        try{
            CharsetDecoder d=StandardCharsets.UTF_8.newDecoder();
            d.onMalformedInput(CodingErrorAction.REPORT);
            d.onUnmappableCharacter(CodingErrorAction.REPORT);
            return d.decode(java.nio.ByteBuffer.wrap(data)).toString();
        }catch(Exception e){
            return new String(data,StandardCharsets.ISO_8859_1);
        }
    }

    private Session open()throws Exception{
        String host=c.getSharedPreferences("mail_prefs",0).getString("host","nastuesta.synology.me");
        String user=c.getSharedPreferences("mail_prefs",0).getString("user",c.getSharedPreferences("cfg",0).getString("user","sergio"));
        String pw=CryptoStore.get(c,"mail_password");
        if(pw==null||pw.isBlank())pw=CryptoStore.get(c,"password");
        if(pw==null||pw.isBlank())throw new Exception("Falta contraseña de MailPlus");
        SSLSocket s=(SSLSocket)SSLSocketFactory.getDefault().createSocket(host,993);
        SSLParameters sp=s.getSSLParameters();sp.setEndpointIdentificationAlgorithm("HTTPS");s.setSSLParameters(sp);
        s.setSoTimeout(20000);s.startHandshake();
        BufferedInputStream in=new BufferedInputStream(s.getInputStream());
        BufferedOutputStream out=new BufferedOutputStream(s.getOutputStream());
        String hello=readLine(in);
        if(hello==null||!hello.startsWith("*")){try{s.close();}catch(Exception ignored){}throw new IOException("El servidor IMAP no respondió");}
        cmd(out,in,"A1 LOGIN "+q(user)+" "+q(pw),"A1");
        cmd(out,in,"A2 SELECT INBOX","A2");
        return new Session(s,in,out);
    }

    private void close(Session ss){
        if(ss==null)return;
        try{cmd(ss.out,ss.in,"ZZ LOGOUT","ZZ");}catch(Exception ignored){}
        try{ss.socket.close();}catch(Exception ignored){}
    }

    private static class Session{
        final SSLSocket socket;final BufferedInputStream in;final BufferedOutputStream out;
        Session(SSLSocket s,BufferedInputStream i,BufferedOutputStream o){socket=s;in=i;out=o;}
    }

    private String literalBody(List<String> lines,String tag){
        if(lines==null||lines.size()<2)return "";
        int start=1,end=lines.size();
        for(int i=start;i<lines.size();i++){if(lines.get(i).startsWith(tag+" ")){end=i;break;}}
        StringBuilder b=new StringBuilder();
        for(int i=start;i<end;i++){if(i>start)b.append("\r\n");b.append(lines.get(i));}
        return b.toString();
    }

    private static class ParsedPart{String body="";boolean html=false;ParsedPart(){}ParsedPart(String b,boolean h){body=b;html=h;}}

    private ParsedPart parsePart(String raw){
        int sep=headerEnd(raw);String head=sep>=0?raw.substring(0,sep):"";String body=sep>=0?raw.substring(bodyStart(raw,sep)):raw;
        Map<String,String> h=parseHeadersText(head);
        String ct=h.getOrDefault("content-type","text/plain");
        String disp=h.getOrDefault("content-disposition","");
        if(disp.toLowerCase(Locale.ROOT).contains("attachment"))return new ParsedPart();
        String low=ct.toLowerCase(Locale.ROOT);
        if(low.startsWith("multipart/")){
            String boundary=param(ct,"boundary");
            if(boundary.isBlank())return new ParsedPart("",false);
            List<String> parts=splitMultipart(body,boundary);
            ParsedPart html=null;
            for(String x:parts){
                ParsedPart pp=parsePart(x);
                if(pp.body==null||pp.body.isBlank())continue;
                if(!pp.html)return pp;
                if(html==null)html=pp;
            }
            return html==null?new ParsedPart("",false):html;
        }
        if(low.startsWith("message/rfc822"))return parsePart(body);
        if(!low.startsWith("text/plain")&&!low.startsWith("text/html"))return new ParsedPart();
        String enc=h.getOrDefault("content-transfer-encoding","").trim().toLowerCase(Locale.ROOT);
        String charset=param(ct,"charset");if(charset.isBlank())charset="UTF-8";
        String decoded=decodeBody(body,enc,charset);
        return new ParsedPart(decoded,low.startsWith("text/html"));
    }

    private int headerEnd(String s){int a=s.indexOf("\r\n\r\n");if(a>=0)return a;return s.indexOf("\n\n");}
    private int bodyStart(String s,int sep){return s.startsWith("\r\n\r\n",sep)?sep+4:sep+2;}

    private Map<String,String> parseHeaderBlock(String raw){int x=headerEnd(raw);return parseHeadersText(x>=0?raw.substring(0,x):raw);}
    private Map<String,String> parseHeadersText(String text){
        Map<String,String> m=new LinkedHashMap<>();String key=null;
        for(String l:text.split("\r?\n")){
            if((l.startsWith(" ")||l.startsWith("\t"))&&key!=null){m.put(key,m.get(key)+" "+l.trim());continue;}
            int x=l.indexOf(':');if(x>0){key=l.substring(0,x).trim().toLowerCase(Locale.ROOT);m.put(key,l.substring(x+1).trim());}
        }
        return m;
    }

    private List<String> splitMultipart(String body,String boundary){
        List<String> out=new ArrayList<>();String marker="--"+boundary;String end=marker+"--";
        StringBuilder cur=null;
        for(String line:body.split("\r?\n",-1)){
            if(line.equals(marker)||line.equals(end)){
                if(cur!=null&&cur.length()>0)out.add(cur.toString());
                cur=line.equals(end)?null:new StringBuilder();
                if(line.equals(end))break;
            }else if(cur!=null){if(cur.length()>0)cur.append("\r\n");cur.append(line);}
        }
        if(cur!=null&&cur.length()>0)out.add(cur.toString());
        return out;
    }

    private String decodeBody(String body,String enc,String charset){
        try{
            byte[] data;
            if(enc.equals("base64"))data=Base64.getMimeDecoder().decode(body.replaceAll("\\s+",""));
            else if(enc.equals("quoted-printable"))data=decodeQuotedPrintable(body);
            else data=body.getBytes(StandardCharsets.ISO_8859_1);
            Charset cs;try{cs=Charset.forName(charset.replace("\"","").trim());}catch(Exception e){cs=StandardCharsets.UTF_8;}
            String decoded=new String(data,cs).trim();
            if(!enc.equals("base64")&&!enc.equals("quoted-printable")&&decoded.indexOf('\uFFFD')>=0)return body.trim();
            return decoded;
        }catch(Exception e){return body.trim();}
    }

    private byte[] decodeQuotedPrintable(String s)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] a=s.getBytes(StandardCharsets.ISO_8859_1);
        for(int i=0;i<a.length;i++){
            int ch=a[i]&255;
            if(ch=='='&&i+1<a.length){
                if(a[i+1]=='\r'&&i+2<a.length&&a[i+2]=='\n'){i+=2;continue;}
                if(a[i+1]=='\n'){i+=1;continue;}
                if(i+2<a.length){int hi=Character.digit((char)a[i+1],16),lo=Character.digit((char)a[i+2],16);if(hi>=0&&lo>=0){b.write((hi<<4)|lo);i+=2;continue;}}
            }
            b.write(ch);
        }
        return b.toByteArray();
    }

    private String param(String header,String name){
        Matcher m=Pattern.compile("(?i)(?:^|;)\\s*"+Pattern.quote(name)+"\\s*=\\s*(?:\"([^\"]*)\"|([^;\\s]*))").matcher(header);
        if(m.find())return m.group(1)!=null?m.group(1):m.group(2);return "";
    }

    private Map<String,String> headers(List<String> lines){
        Map<String,String> m=new LinkedHashMap<>();String key=null;
        for(String l:lines){if(l==null)continue;if((l.startsWith(" ")||l.startsWith("\t"))&&key!=null){m.put(key,m.get(key)+" "+l.trim());continue;}int x=l.indexOf(':');if(x>0){String k=l.substring(0,x).trim().toLowerCase(Locale.ROOT);if(k.equals("from")||k.equals("subject")||k.equals("date")){key=k;m.put(k,l.substring(x+1).trim());}}}
        return m;
    }

    private String cleanFrom(String s){String x=s.replaceAll("<[^>]+>","").trim();if(x.startsWith("\"")&&x.endsWith("\"")&&x.length()>1)x=x.substring(1,x.length()-1);if(x.isBlank()){Matcher m=Pattern.compile("<([^>]+)>").matcher(s);if(m.find())x=m.group(1);}return x;}
    private String extractAddress(String s){Matcher m=Pattern.compile("<([^>]+)>").matcher(s);if(m.find())return m.group(1).trim();Matcher e=Pattern.compile("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}",Pattern.CASE_INSENSITIVE).matcher(s);return e.find()?e.group():s.trim();}

    private String prettyDate(String s){String[] pats={"EEE, d MMM yyyy HH:mm:ss Z","EEE, d MMM yyyy HH:mm Z","d MMM yyyy HH:mm:ss Z"};for(String p:pats)try{Date d=new SimpleDateFormat(p,Locale.US).parse(s.replaceAll("\\s*\\([^)]*\\)\\s*$",""));if(d!=null)return new SimpleDateFormat("dd/MM/yyyy · HH:mm",new Locale("es","ES")).format(d);}catch(Exception ignored){}return s;}

    private String decodeWords(String s){if(s==null)return "";Pattern p=Pattern.compile("=\\?([^?]+)\\?([bBqQ])\\?([^?]*)\\?=");Matcher m=p.matcher(s);StringBuffer b=new StringBuffer();while(m.find()){String rep=m.group();try{Charset cs=Charset.forName(m.group(1));byte[] data;if(m.group(2).equalsIgnoreCase("B"))data=Base64.getDecoder().decode(m.group(3));else data=decodeQ(m.group(3));rep=new String(data,cs);}catch(Exception ignored){}m.appendReplacement(b,Matcher.quoteReplacement(rep));}m.appendTail(b);return b.toString().replaceAll("\\s+"," ").trim();}
    private byte[] decodeQ(String s)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();for(int i=0;i<s.length();i++){char ch=s.charAt(i);if(ch=='_')b.write(' ');else if(ch=='='&&i+2<s.length()){b.write(Integer.parseInt(s.substring(i+1,i+3),16));i+=2;}else b.write((byte)ch);}return b.toByteArray();}

    private List<String> cmd(OutputStream out,BufferedInputStream in,String c,String tag)throws Exception{
        out.write((c+"\r\n").getBytes(StandardCharsets.UTF_8));out.flush();List<String> r=new ArrayList<>();
        while(true){String l=readLine(in);if(l==null)throw new EOFException();r.add(l);Matcher m=Pattern.compile("\\{(\\d+)\\}$").matcher(l);if(m.find()){int n=Integer.parseInt(m.group(1));byte[] b=in.readNBytes(n);if(b.length!=n)throw new EOFException("Respuesta IMAP incompleta");String body=new String(b,StandardCharsets.UTF_8);r.addAll(Arrays.asList(body.split("\\r?\\n",-1)));readLine(in);}if(l.startsWith(tag+" ")){if(!l.toUpperCase(Locale.ROOT).contains(" OK"))throw new IOException(l);break;}}
        return r;
    }

    private String readLine(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();int p=-1,x;while((x=in.read())!=-1){if(p=='\r'&&x=='\n'){byte[] a=b.toByteArray();return new String(a,0,Math.max(0,a.length-1),StandardCharsets.UTF_8);}b.write(x);p=x;}return null;}
}
