package es.sergio.synologyagenda;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.Typeface;import android.text.*;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class AgendaActivity extends Activity {
    LinearLayout list; TextView status,mailBadge; EditText search; ScrollView scroll; String query=""; View todayAnchor; boolean initialPositionDone=false;
    final int bg=Color.rgb(5,13,20), card=Color.rgb(14,31,45), card2=Color.rgb(17,37,54), text=Color.rgb(246,249,255), muted=Color.rgb(164,184,211), accent=Color.rgb(54,158,255), cyan=Color.rgb(48,199,255), green=Color.rgb(77,222,166), line=Color.rgb(38,77,111);

    @Override public void onCreate(Bundle b){super.onCreate(b);build();String q=getIntent().getStringExtra("search");if(q!=null&&!q.isBlank()){search.setText(q);query=q.trim().toLowerCase(Locale.ROOT);}render();refresh();}

    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(8),dp(18),dp(12));root.setBackgroundColor(bg);
        root.setOnApplyWindowInsetsListener((v,in)->{int top=in.getInsets(android.view.WindowInsets.Type.statusBars()).top;v.setPadding(dp(18),top+dp(8),dp(18),dp(12));return in;});

        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout dateBox=new LinearLayout(this);dateBox.setOrientation(LinearLayout.VERTICAL);
        Calendar now=Calendar.getInstance();String weekday=cap(new SimpleDateFormat("EEEE",new Locale("es","ES")).format(now.getTime()));
        TextView wd=t(weekday,25,true,text);dateBox.addView(wd);
        LinearLayout dateLine=new LinearLayout(this);dateLine.setGravity(Gravity.BOTTOM);TextView num=t(String.valueOf(now.get(Calendar.DAY_OF_MONTH)),52,true,accent);dateLine.addView(num);TextView month=t(" de "+new SimpleDateFormat("MMMM",new Locale("es","ES")).format(now.getTime()),17,false,muted);month.setPadding(dp(4),0,0,dp(7));dateLine.addView(month);dateBox.addView(dateLine);
        int week=now.get(Calendar.WEEK_OF_YEAR);TextView wk=t("▣  Semana "+week+" · "+now.get(Calendar.YEAR),12,false,muted);wk.setPadding(dp(4),0,0,dp(2));dateBox.addView(wk);bar.addView(dateBox,new LinearLayout.LayoutParams(0,-2,1));

        View create=roundIcon(AgendaIconView.PLUS,true,accent);FrameLayout mail=mailButton();View refresh=roundIcon(AgendaIconView.REFRESH,false,green),settings=roundIcon(AgendaIconView.SETTINGS,false,text);bar.addView(create);bar.addView(mail);bar.addView(refresh);bar.addView(settings);root.addView(bar);

        LinearLayout searchWrap=new LinearLayout(this);searchWrap.setGravity(Gravity.CENTER_VERTICAL);searchWrap.setPadding(dp(12),0,dp(10),0);searchWrap.setBackground(stroked(card,20,line));searchWrap.addView(new AgendaIconView(this,AgendaIconView.SEARCH,muted),new LinearLayout.LayoutParams(dp(30),dp(30)));
        search=new EditText(this);search.setSingleLine(true);search.setHint("Buscar evento, descripción, ubicación…");search.setHintTextColor(Color.rgb(112,125,143));search.setTextColor(text);search.setTextSize(15);search.setPadding(dp(8),dp(12),dp(8),dp(12));search.setBackgroundColor(Color.TRANSPARENT);searchWrap.addView(search,new LinearLayout.LayoutParams(0,-2,1));searchWrap.addView(new AgendaIconView(this,AgendaIconView.SLIDERS,muted),new LinearLayout.LayoutParams(dp(30),dp(30)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.setMargins(0,dp(13),0,dp(5));root.addView(searchWrap,sp);
        status=t("",12,false,muted);status.setPadding(dp(2),dp(4),0,dp(6));root.addView(status);

        scroll=new ScrollView(this);scroll.setFillViewport(true);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(0,0,0,dp(24));scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);

        create.setOnClickListener(v->createEvent());mail.setOnClickListener(v->openMailPlus());settings.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));refresh.setOnClickListener(v->refresh());
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){query=s.toString().trim().toLowerCase(Locale.ROOT);initialPositionDone=true;render();scroll.post(()->scroll.scrollTo(0,0));}public void afterTextChanged(Editable e){}});
        updateUnreadBadge();
    }

    FrameLayout mailButton(){FrameLayout outer=new FrameLayout(this);outer.setBackground(stroked(Color.rgb(10,31,48),24,line));outer.addView(new AgendaIconView(this,AgendaIconView.MAIL,text),new FrameLayout.LayoutParams(-1,-1));mailBadge=t("",10,true,Color.WHITE);mailBadge.setGravity(Gravity.CENTER);mailBadge.setBackground(round(Color.rgb(244,67,83),12));mailBadge.setVisibility(View.GONE);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(24),dp(24),Gravity.TOP|Gravity.END);bp.setMargins(0,-dp(4),-dp(4),0);outer.addView(mailBadge,bp);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(44),dp(44));p.setMargins(dp(5),0,0,0);outer.setLayoutParams(p);return outer;}

    void updateUnreadBadge(){new Thread(()->{try{int n=new ImapClient(this).unreadCount();runOnUiThread(()->{mailBadge.setText(n>99?"99+":String.valueOf(n));mailBadge.setVisibility(n>0?View.VISIBLE:View.GONE);});}catch(Exception e){runOnUiThread(()->mailBadge.setVisibility(View.GONE));}}).start();}
    void createEvent(){ startActivityForResult(new Intent(this,CreateEventActivity.class),501); }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==501 && resultCode==RESULT_OK){ initialPositionDone=false; refresh(); } }

    void render(){
        list.removeAllViews();todayAnchor=null;
        List<EventItem> es=new ArrayList<>(WidgetCache.load(this));es.sort(Comparator.comparingLong(a->a.start));
        if(!query.isBlank()){List<EventItem> f=new ArrayList<>();for(EventItem e:es){String hay=(safe(e.title)+" "+safe(e.description)+" "+safe(e.location)+" "+safe(e.calendarName)).toLowerCase(Locale.ROOT);if(hay.contains(query))f.add(e);}es=f;}

        String last="";SimpleDateFormat key=new SimpleDateFormat("yyyyMMdd",Locale.US),day=new SimpleDateFormat("EEEE d 'de' MMMM",new Locale("es","ES")),time=new SimpleDateFormat("HH:mm",Locale.getDefault());
        Calendar today=Calendar.getInstance();today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);today.set(Calendar.SECOND,0);today.set(Calendar.MILLISECOND,0);long todayMs=today.getTimeInMillis();
        Calendar tomorrow=(Calendar)today.clone();tomorrow.add(Calendar.DAY_OF_YEAR,1);

        for(EventItem e:es){
            Date d=new Date(e.start*1000L);String k=key.format(d);
            if(!k.equals(last)){
                Calendar ec=Calendar.getInstance();ec.setTime(d);String label=cap(day.format(d));
                if(sameDay(today,ec))label="HOY · "+label;else if(sameDay(tomorrow,ec))label="MAÑANA · "+label;
                LinearLayout dh=new LinearLayout(this);dh.setGravity(Gravity.CENTER_VERTICAL);dh.setPadding(dp(4),dp(18),0,dp(8));int hc=e.start*1000L>=todayMs?accent:muted;dh.addView(new AgendaIconView(this,AgendaIconView.CALENDAR,hc),new LinearLayout.LayoutParams(dp(28),dp(28)));TextView dht=t(label,e.start*1000L>=todayMs?17:14,true,hc);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(0,-2,1);dlp.setMargins(dp(6),0,0,0);dh.addView(dht,dlp);list.addView(dh);
                if(todayAnchor==null && e.start*1000L>=todayMs) todayAnchor=dh;
                last=k;
            }

            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(10),dp(12),dp(10));row.setBackground(stroked(e.start*1000L>=todayMs?card2:card,16,line));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,0,0,dp(7));row.setLayoutParams(rp);
            int c=ColorUtil.eventCalendarColor(e,true,accent);TextView marker=t("▏  ●",15,true,c);row.addView(marker,new LinearLayout.LayoutParams(dp(44),-2));
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);TextView title=t(e.title,16,true,e.start*1000L>=todayMs?text:muted);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);body.addView(title);
            String meta=(e.allDay?"Todo el día":time.format(d));if(!safe(e.calendarName).isBlank())meta+="  ·  "+e.calendarName;TextView m=t(meta,13,false,muted);m.setPadding(0,dp(2),0,0);body.addView(m);
            if(!safe(e.location).isBlank()){TextView l=t("📍 "+e.location,12,false,muted);l.setMaxLines(1);l.setEllipsize(TextUtils.TruncateAt.END);body.addView(l);}row.addView(body,new LinearLayout.LayoutParams(0,-2,1));row.addView(t("›",27,false,muted));
            row.setOnClickListener(v->{Intent i=new Intent(this,EventDetailActivity.class);i.putExtra("evt_id",e.evtId);i.putExtra("recurrence_id",e.recurrenceId);startActivity(i);});list.addView(row);
        }

        if(es.isEmpty()){TextView empty=t(query.isBlank()?"No hay eventos en la agenda.":"No se encontraron eventos con “"+query+"”.",17,false,muted);empty.setGravity(Gravity.CENTER);empty.setPadding(0,dp(70),0,0);list.addView(empty);}
        if(query.isBlank() && todayAnchor==null && !es.isEmpty()){TextView now=t("HOY · "+cap(day.format(new Date())).toUpperCase(new Locale("es","ES")),12,true,accent);now.setPadding(dp(4),dp(20),0,dp(7));list.addView(now);TextView none=t("No hay eventos desde hoy.",15,false,muted);none.setGravity(Gravity.CENTER);none.setPadding(dp(10),dp(22),dp(10),dp(22));none.setBackground(round(card2,18));list.addView(none);todayAnchor=now;}
        long up=WidgetCache.updated(this);status.setText((query.isBlank()?"●  ":es.size()+" resultados · ")+(up>0?"Sincronizado · "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(up)):"Pendiente de actualización")); status.setTextColor(up>0?green:muted);

        if(query.isBlank() && !initialPositionDone){initialPositionDone=true;scroll.postDelayed(()->{if(todayAnchor!=null){todayAnchor.requestFocus();scroll.scrollTo(0,Math.max(0,todayAnchor.getTop()-dp(4)));}},180);}
    }

    void openMailPlus(){try{Intent i=getPackageManager().getLaunchIntentForPackage("com.synology.dsmail");if(i!=null){startActivity(i);return;}}catch(Exception ignored){}Toast.makeText(this,"MailPlus no está disponible",Toast.LENGTH_SHORT).show();}
    void refresh(){status.setText("Actualizando Calendar y MailPlus…");updateUnreadBadge();new Thread(()->{WidgetUpdater.updateAll(this);runOnUiThread(()->{initialPositionDone=false;render();});}).start();}
    @Override protected void onResume(){super.onResume();if(mailBadge!=null)updateUnreadBadge();}

    TextView brandTitle(){ android.text.SpannableString sp=new android.text.SpannableString("Agenda Synology"); sp.setSpan(new android.text.style.ForegroundColorSpan(text),0,7,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); sp.setSpan(new android.text.style.ForegroundColorSpan(accent),7,sp.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); TextView v=t("",29,true,text);v.setText(sp);return v;}
    android.graphics.drawable.GradientDrawable stroked(int color,int radius,int stroke){android.graphics.drawable.GradientDrawable g=round(color,radius);g.setStroke(dp(1),stroke);return g;}
    View roundIcon(int type,boolean selected,int iconColor){FrameLayout x=new FrameLayout(this);android.graphics.drawable.GradientDrawable g=round(selected?Color.rgb(8,42,72):Color.rgb(10,31,48),24);g.setStroke(dp(selected?2:1),selected?accent:line);x.setBackground(g);x.addView(new AgendaIconView(this,type,iconColor),new FrameLayout.LayoutParams(-1,-1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(44),dp(44));p.setMargins(dp(5),0,0,0);x.setLayoutParams(p);return x;}
    TextView t(String s,int z,boolean bold,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(z);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}boolean sameDay(Calendar a,Calendar b){return a.get(Calendar.YEAR)==b.get(Calendar.YEAR)&&a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR);}String cap(String s){return s==null||s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1);}String safe(String s){return s==null?"":s;}
}
