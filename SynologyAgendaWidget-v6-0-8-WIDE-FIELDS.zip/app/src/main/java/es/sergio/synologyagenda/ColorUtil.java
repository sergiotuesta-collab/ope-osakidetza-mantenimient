package es.sergio.synologyagenda;
import android.graphics.Color;
public final class ColorUtil {
    private ColorUtil(){}
    public static int parseCalendarColor(String s, int fallback){
        try { if(s!=null && s.matches("#[0-9a-fA-F]{6,8}")) return Color.parseColor(s.substring(0,7)); } catch(Exception ignored){}
        return fallback;
    }
    public static int readableCalendarColor(String s, boolean darkBackground, int fallback){
        int c=parseCalendarColor(s,fallback);
        double lum=(0.2126*Color.red(c)+0.7152*Color.green(c)+0.0722*Color.blue(c))/255.0;
        if(darkBackground && lum<0.32) return blend(c, Color.WHITE, .38f);
        if(!darkBackground && lum>0.80) return blend(c, Color.BLACK, .34f);
        return c;
    }
    public static int eventCalendarColor(EventItem e, boolean darkBackground, int fallback){
        if(e!=null && e.calendarColor!=null && e.calendarColor.matches("#[0-9a-fA-F]{6,8}")) return readableCalendarColor(e.calendarColor,darkBackground,fallback);
        int[] palette={Color.rgb(32,166,255),Color.rgb(255,205,57),Color.rgb(135,83,255),Color.rgb(48,218,176),Color.rgb(255,92,143),Color.rgb(255,145,58),Color.rgb(69,194,255)};
        String key=e==null?"":((e.calId==null?"":e.calId)+"|"+(e.originalCalId==null?"":e.originalCalId)+"|"+(e.calendarName==null?"":e.calendarName));
        int idx=(key.hashCode() & 0x7fffffff)%palette.length;
        return palette[idx];
    }
    private static int blend(int a,int b,float f){return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f));}
}
