package es.sergio.synologyagenda;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/** Actividad invisible: cualquier toque en los widgets abre la app Synology MailPlus. */
public class WidgetOpenActivity extends Activity {
    public static final String EXTRA_TARGET="target";

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        Intent in=getIntent();
        String t=in.getStringExtra(EXTRA_TARGET);
        if(t==null||t.isBlank())t=MailPlusLauncher.T_CALENDAR;
        // Todos los toques del widget abren la app Synology MailPlus.
        // MailPlus (3.0.2) no permite abrir un evento o mensaje concreto desde otra app,
        // así que se abre MailPlus por su pantalla principal.
        if(!MailPlusLauncher.open(this,t,in))Toast.makeText(this,"No se ha podido abrir MailPlus. ¿Está instalada?",Toast.LENGTH_LONG).show();
        finish();
    }
}
