package es.sergio.synologyagenda;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Actividad invisible que recibe los toques de los widgets y decide dónde abrir:
 * en MailPlus (por defecto) o en las pantallas propias de Agenda Synology
 * (comportamiento anterior, seleccionable en Configuración).
 */
public class WidgetOpenActivity extends Activity {
    public static final String EXTRA_TARGET="target";

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        Intent in=getIntent();
        String t=in.getStringExtra(EXTRA_TARGET);
        if(t==null||t.isBlank())t=MailPlusLauncher.T_CALENDAR;
        boolean done=false;
        // MailPlus (3.0.2) no permite abrir un evento o mensaje concreto desde otra app:
        // la fecha y la bandeja abren MailPlus; un evento o mensaje abren su ficha aquí.
        boolean toMailPlus=MailPlusLauncher.T_CALENDAR.equals(t)||MailPlusLauncher.T_INBOX.equals(t);
        if(toMailPlus&&WidgetPrefs.openInMailPlus(this)){
            done=MailPlusLauncher.open(this,t,in);
            if(!done)Toast.makeText(this,"No se ha podido abrir MailPlus. Se abre en Agenda Synology.",Toast.LENGTH_LONG).show();
        }
        if(!done)openInternal(t,in);
        finish();
    }

    private void openInternal(String t,Intent src){
        Class<?> cls;
        switch(t){
            case MailPlusLauncher.T_EVENT: cls=EventDetailActivity.class; break;
            case MailPlusLauncher.T_MESSAGE: cls=MailActivity.class; break;
            case MailPlusLauncher.T_INBOX: cls=HomeActivity.class; break;
            default: cls=AgendaActivity.class; break;
        }
        Intent i=new Intent(this,cls);
        if(src.getExtras()!=null)i.putExtras(src.getExtras());
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try{startActivity(i);}catch(Exception e){Toast.makeText(this,"No se ha podido abrir la pantalla.",Toast.LENGTH_SHORT).show();}
    }
}
