package es.sergio.synologyagenda;

import android.content.Context;
import android.graphics.*;
import android.util.Base64;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.*;

public final class WidgetAttachmentCache {
    private WidgetAttachmentCache(){}
    public static final class Summary {
        public final int count; public final long totalBytes; public final String firstName, firstType, previewB64;
        Summary(int c,long b,String n,String t,String p){count=c;totalBytes=b;firstName=n==null?"":n;firstType=t==null?"":t;previewB64=p==null?"":p;}
    }
    public static void save(Context c, Map<Long,List<SynologyClient.NasFile>> map, Map<Long,byte[]> previews){
        JSONObject root=new JSONObject();
        try{
            for(Map.Entry<Long,List<SynologyClient.NasFile>> en:map.entrySet()){
                List<SynologyClient.NasFile> fs=en.getValue(); if(fs==null||fs.isEmpty())continue;
                long total=0; for(SynologyClient.NasFile f:fs)total+=Math.max(0,f.size);
                SynologyClient.NasFile first=fs.get(0);
                JSONObject o=new JSONObject();o.put("count",fs.size());o.put("bytes",total);o.put("first",first.name);o.put("type",typeOf(first.name));
                byte[] pv=previews==null?null:previews.get(en.getKey()); if(pv!=null&&pv.length>0){String b=smallPreview(pv);if(!b.isEmpty())o.put("preview",b);}
                root.put(Long.toString(en.getKey()),o);
            }
        }catch(Exception ignored){}
        c.getSharedPreferences("widget_attachment_cache",Context.MODE_PRIVATE).edit().putString("items",root.toString()).putLong("updated",System.currentTimeMillis()).apply();
    }
    public static Summary get(Context c,long evtId){
        try{
            String raw=c.getSharedPreferences("widget_attachment_cache",Context.MODE_PRIVATE).getString("items","{}");
            JSONObject o=new JSONObject(raw).optJSONObject(Long.toString(evtId));
            if(o==null)return new Summary(0,0,"","","");
            return new Summary(o.optInt("count",0),o.optLong("bytes",0),o.optString("first",""),o.optString("type",""),o.optString("preview",""));
        }catch(Exception e){return new Summary(0,0,"","","");}
    }
    public static Bitmap previewBitmap(Summary s){try{if(s==null||s.previewB64.isEmpty())return null;byte[] b=Base64.decode(s.previewB64,Base64.DEFAULT);return BitmapFactory.decodeByteArray(b,0,b.length);}catch(Exception e){return null;}}
    public static boolean imageName(String n){String x=n==null?"":n.toLowerCase(Locale.ROOT);return x.endsWith(".jpg")||x.endsWith(".jpeg")||x.endsWith(".png")||x.endsWith(".webp")||x.endsWith(".gif")||x.endsWith(".heic");}
    private static String typeOf(String n){String x=n==null?"":n.toLowerCase(Locale.ROOT);if(imageName(x))return "IMG";if(x.endsWith(".pdf"))return "PDF";if(x.endsWith(".doc")||x.endsWith(".docx"))return "DOC";if(x.endsWith(".xls")||x.endsWith(".xlsx"))return "XLS";if(x.endsWith(".ppt")||x.endsWith(".pptx"))return "PPT";if(x.endsWith(".txt"))return "TXT";return "FILE";}
    private static String smallPreview(byte[] raw){
        try{Bitmap b=BitmapFactory.decodeByteArray(raw,0,raw.length);if(b==null)return "";int max=96;float k=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));Bitmap s=Bitmap.createScaledBitmap(b,Math.max(1,(int)(b.getWidth()*k)),Math.max(1,(int)(b.getHeight()*k)),true);ByteArrayOutputStream o=new ByteArrayOutputStream();s.compress(Bitmap.CompressFormat.JPEG,72,o);return Base64.encodeToString(o.toByteArray(),Base64.NO_WRAP);}catch(Exception e){return "";}
    }
}
