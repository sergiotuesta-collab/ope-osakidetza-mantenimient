package es.sergio.synologyagenda;

import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import java.util.*;

/**
 * Abre la app oficial Synology MailPlus (com.synology.dsmail) desde los widgets.
 * Cada intento se comprueba con resolveActivity() antes de lanzarlo, así que nunca se
 * dispara un intent que MailPlus no declare. Si no hay ruta directa, se abre MailPlus
 * por su pantalla principal (launcher).
 */
public final class MailPlusLauncher {
    private MailPlusLauncher(){}
    public static final String PKG="com.synology.dsmail";
    public static final String T_CALENDAR="calendar",T_EVENT="event",T_INBOX="inbox",T_MESSAGE="message";

    public static boolean installed(Context c){
        try{c.getPackageManager().getPackageInfo(PKG,0);return true;}catch(Exception e){return false;}
    }

    /** Devuelve true si se ha podido abrir MailPlus. */
    public static boolean open(Context c,String target,Intent src){
        PackageManager pm=c.getPackageManager();
        for(Intent i:candidates(c,target,src)){
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try{
                if(i.resolveActivity(pm)==null)continue;
                c.startActivity(i);
                return true;
            }catch(Exception ignored){}
        }
        return false;
    }

    static List<Intent> candidates(Context c,String target,Intent src){
        List<Intent> out=new ArrayList<>();
        // MailPlus 3.0.2 solo exporta SplashActivity (MAIN/LAUNCHER) y no reenvía extras ni datos:
        // no hay forma pública de abrir directamente el calendario, un evento o un mensaje.
        // Si una versión futura añade rutas, se añadirán aquí (comprobadas con resolveActivity).
        Intent launch=null;
        try{launch=c.getPackageManager().getLaunchIntentForPackage(PKG);}catch(Exception ignored){}
        if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);out.add(launch);}
        else{Intent m=new Intent(Intent.ACTION_MAIN);m.addCategory(Intent.CATEGORY_LAUNCHER);m.setPackage(PKG);out.add(m);}
        return out;
    }

    /** Texto de diagnóstico: versión de MailPlus, actividades que expone y rutas que resuelven. */
    public static String diagnose(Context c){
        StringBuilder sb=new StringBuilder();
        PackageManager pm=c.getPackageManager();
        sb.append("Agenda Synology → MailPlus\n");
        PackageInfo pi;
        try{pi=pm.getPackageInfo(PKG,PackageManager.GET_ACTIVITIES);}
        catch(Exception e){return sb.append("MailPlus (").append(PKG).append(") no está instalado o no es visible.").toString();}
        sb.append("Versión MailPlus: ").append(pi.versionName).append('\n');
        if(pi.activities!=null){
            sb.append("\nActividades exportadas:\n");
            for(ActivityInfo a:pi.activities)if(a.exported)sb.append("• ").append(a.name).append('\n');
        }
        Intent l=null;try{l=pm.getLaunchIntentForPackage(PKG);}catch(Exception ignored){}
        ComponentName cn=l==null?null:l.getComponent();
        sb.append("\nApertura desde widgets: ").append(cn==null?"no disponible":cn.getClassName()).append('\n');
        return sb.toString();
    }
}
