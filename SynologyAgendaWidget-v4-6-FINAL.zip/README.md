# Agenda Synology v4.2

Actualización incremental firmada sobre la v4/v4.1.

Cambios principales:
- Al tocar un correo del widget se abre el mensaje concreto dentro de Agenda Synology.
- Lectura del cuerpo del correo por IMAPS con soporte básico para multipart, texto, HTML, Base64 y quoted-printable.
- El correo se marca como leído después de abrirse correctamente y el widget actualiza el indicador.
- Vista HTML endurecida: JavaScript, acceso a archivos y carga de recursos remotos desactivados.
- Botones Responder, Reenviar y Abrir MailPlus con fallback seguro si MailPlus no admite la acción.
- Botón de configuración ⚙ más pequeño y discreto en los widgets.
- Se mantienen la firma permanente, el applicationId y los datos de configuración existentes.

versionCode 6 / versionName 4.2
