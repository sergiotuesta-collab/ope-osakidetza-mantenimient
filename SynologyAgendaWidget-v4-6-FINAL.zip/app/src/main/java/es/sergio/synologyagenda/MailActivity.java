package es.sergio.synologyagenda;

import android.app.*;
import android.appwidget.AppWidgetManager;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.text.TextUtils;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MailActivity extends Activity{
    long uid; boolean fromWidget; LinearLayout root,content; ProgressBar progress; TextView status;
    String fallbackFrom,fallbackSubject,fallbackDate; MailMessage message;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        uid=getIntent().getLongExtra("uid",0);fromWidget=getIntent().getBooleanExtra("from_widget",false);
        fallbackFrom=n(getIntent().getStringExtra("from"));fallbackSubject=n(getIntent().getStringExtra("subject"));fallbackDate=n(getIntent().getStringExtra("date"));
        build(); load();
    }

    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(17,18,20));
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(18),dp(20),dp(28));scroll.addView(root,new ScrollView.LayoutParams(-1,-2));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=buttonText("‹",30);back.setContentDescription("Volver");back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(dp(42),dp(42)));
        TextView title=t("Correo",18,true,Color.WHITE);LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(0,-2,1);top.addView(title,tl);
        TextView settings=buttonText("⚙",16);settings.setContentDescription("Configuración");settings.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));top.addView(settings,new LinearLayout.LayoutParams(dp(36),dp(36)));
        root.addView(top);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);root.addView(content,new LinearLayout.LayoutParams(-1,-2));
        TextView subj=t(fallbackSubject.isBlank()?"(Sin asunto)":fallbackSubject,23,true,Color.WHITE);subj.setPadding(0,dp(18),0,dp(10));content.addView(subj);
        content.addView(t(fallbackFrom,16,true,Color.rgb(225,229,235)));
        content.addView(t(fallbackDate,13,false,Color.rgb(155,164,176)));
        progress=new ProgressBar(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(32),dp(32));pp.gravity=Gravity.CENTER_HORIZONTAL;pp.setMargins(0,dp(28),0,dp(12));content.addView(progress,pp);
        status=t("Cargando mensaje…",14,false,Color.rgb(160,168,180));status.setGravity(Gravity.CENTER);content.addView(status);
        setContentView(scroll);
    }

    private void load(){
        if(uid<=0){showError("No se ha recibido el identificador del mensaje.");return;}
        new Thread(()->{
            try{MailMessage m=new ImapClient(this).message(uid);runOnUiThread(()->showMessage(m));}
            catch(Exception e){String x=e.getMessage()==null?"No se pudo abrir el correo":e.getMessage();runOnUiThread(()->showError(x));}
        }).start();
    }

    private void showMessage(MailMessage m){
        message=m;content.removeAllViews();
        TextView subj=t(m.subject.isBlank()?"(Sin asunto)":m.subject,23,true,Color.WHITE);subj.setPadding(0,dp(18),0,dp(12));content.addView(subj);
        content.addView(t(m.from.isBlank()?fallbackFrom:m.from,16,true,Color.rgb(232,235,240)));
        if(!m.fromAddress.isBlank()&&!m.fromAddress.equalsIgnoreCase(m.from))content.addView(t(m.fromAddress,13,false,Color.rgb(164,173,186)));
        if(!m.to.isBlank())content.addView(t("Para: "+m.to,13,false,Color.rgb(164,173,186)));
        content.addView(t(m.date.isBlank()?fallbackDate:m.date,13,false,Color.rgb(164,173,186)));
        View line=new View(this);line.setBackgroundColor(Color.rgb(46,49,55));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.setMargins(0,dp(16),0,dp(16));content.addView(line,lp);
        if(m.html)content.addView(htmlView(m.body),new LinearLayout.LayoutParams(-1,dp(420)));
        else{TextView body=t(m.body.isBlank()?"(Mensaje sin contenido de texto)":m.body,16,false,Color.rgb(230,233,238));body.setTextIsSelectable(true);body.setLineSpacing(0,1.12f);content.addView(body);}
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setPadding(0,dp(22),0,0);
        Button reply=action("Responder");reply.setOnClickListener(v->compose(false));actions.addView(reply,new LinearLayout.LayoutParams(0,dp(48),1));
        Space sp=new Space(this);actions.addView(sp,new LinearLayout.LayoutParams(dp(8),1));
        Button fwd=action("Reenviar");fwd.setOnClickListener(v->compose(true));actions.addView(fwd,new LinearLayout.LayoutParams(0,dp(48),1));
        content.addView(actions);
        Button open=action("Abrir MailPlus");LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(48));op.setMargins(0,dp(9),0,0);open.setOnClickListener(v->openMailPlus());content.addView(open,op);
        MailCache.markRead(this,uid);refreshMailWidgets();
    }

    private WebView htmlView(String html){
        WebView w=new WebView(this);w.setBackgroundColor(Color.TRANSPARENT);WebSettings s=w.getSettings();s.setJavaScriptEnabled(false);s.setDomStorageEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setLoadsImagesAutomatically(false);try{s.setBlockNetworkLoads(true);}catch(Exception ignored){}
        String safe="<html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{background:#111214;color:#e6e9ee;font-family:sans-serif;font-size:16px;line-height:1.45;word-wrap:break-word}a{color:#8ab4f8}img{max-width:100%;height:auto}</style></head><body>"+html+"</body></html>";
        w.loadDataWithBaseURL(null,safe,"text/html","UTF-8",null);w.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){openExternal(req.getUrl());return true;} @Override public boolean shouldOverrideUrlLoading(WebView view,String url){openExternal(Uri.parse(url));return true;}});return w;
    }

    private void openExternal(Uri u){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(this,"No se puede abrir el enlace",Toast.LENGTH_SHORT).show();}}

    private void compose(boolean forward){
        if(message==null)return;
        String subject=message.subject;
        if(forward){if(!subject.toLowerCase(Locale.ROOT).startsWith("fwd:")&&!subject.toLowerCase(Locale.ROOT).startsWith("rv:"))subject="RV: "+subject;}
        else if(!subject.toLowerCase(Locale.ROOT).startsWith("re:"))subject="Re: "+subject;
        String recipient=forward?"":message.fromAddress;
        Uri uri=Uri.parse("mailto:"+Uri.encode(recipient)+"?subject="+Uri.encode(subject));
        Intent i=new Intent(Intent.ACTION_SENDTO,uri);i.setPackage("com.synology.dsmail");
        try{startActivity(i);}catch(Exception e){i.setPackage(null);try{startActivity(Intent.createChooser(i,forward?"Reenviar con":"Responder con"));}catch(Exception x){Toast.makeText(this,"No hay una aplicación de correo disponible",Toast.LENGTH_LONG).show();}}
    }

    private void openMailPlus(){
        final String pkg="com.synology.dsmail";
        try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);startActivity(i);return;}}catch(Exception ignored){}
        try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);i.setPackage(pkg);startActivity(i);return;}catch(Exception ignored){}
        Toast.makeText(this,"No he podido abrir MailPlus. El mensaje sí está disponible aquí.",Toast.LENGTH_LONG).show();
    }

    private void refreshMailWidgets(){
        Intent i=new Intent(this,MailWidgetProvider.class).setAction("es.sergio.synologyagenda.MAIL_CACHE_CHANGED");sendBroadcast(i);
    }

    private void showError(String msg){
        progress.setVisibility(View.GONE);status.setText("⚠ "+msg);status.setTextColor(Color.rgb(255,180,170));
        Button retry=action("Reintentar");retry.setOnClickListener(v->{retry.setEnabled(false);status.setText("Cargando mensaje…");load();});content.addView(retry,new LinearLayout.LayoutParams(-1,dp(48)));
        Button open=action("Abrir MailPlus");LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.setMargins(0,dp(9),0,0);open.setOnClickListener(v->openMailPlus());content.addView(open,p);
    }

    private Button action(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);return b;}
    private TextView buttonText(String s,int z){TextView v=t(s,z,false,Color.rgb(205,211,220));v.setGravity(Gravity.CENTER);v.setPadding(0,0,0,0);return v;}
    private TextView t(String s,int z,boolean bold,int color){TextView v=new TextView(this);v.setText(n(s));v.setTextColor(color);v.setTextSize(z);if(bold)v.setTypeface(null,1);v.setPadding(0,dp(3),0,dp(5));return v;}
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private String n(String s){return s==null?"":s;}

    @Override public void onBackPressed(){finish();}
}
