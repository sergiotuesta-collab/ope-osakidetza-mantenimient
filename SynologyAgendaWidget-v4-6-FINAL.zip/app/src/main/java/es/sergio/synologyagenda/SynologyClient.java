package es.sergio.synologyagenda;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class SynologyClient {
    private final Context ctx;
    private final String base, user, password;
    private String sid, token, did;

    public SynologyClient(Context c) {
        ctx=c.getApplicationContext();
        android.content.SharedPreferences p=c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        base=normalize(p.getString("server", "https://nastuesta.fr3.quickconnect.to"));
        user=p.getString("user", "sergio");
        password=CryptoStore.get(c,"password"); did=CryptoStore.get(c,"did");
        sid=p.getString("sid", null); token=p.getString("token", null);
    }
    private static String normalize(String s){ s=s==null?"":s.trim(); if(!s.startsWith("https://")) s="https://"+s; while(s.endsWith("/")) s=s.substring(0,s.length()-1); return s; }

    public JSONObject login(String otp, boolean firstTrust) throws Exception {
        if(password==null || password.isBlank()) throw new IOException("Falta la contraseña guardada");
        Map<String,String> q=new LinkedHashMap<>();
        q.put("api","SYNO.API.Auth"); q.put("version","6"); q.put("method","login"); q.put("account",user); q.put("passwd",password);
        q.put("session","Calendar"); q.put("format","sid"); q.put("enable_syno_token","yes");
        if(firstTrust && otp!=null && !otp.isBlank()) { q.put("otp_code",otp.trim()); q.put("enable_device_token","yes"); q.put("device_name","Agenda Synology S25"); }
        else if(did!=null && !did.isBlank()) { q.put("device_name","Agenda Synology S25"); q.put("device_id",did); }
        else if(otp!=null && !otp.isBlank()) q.put("otp_code",otp.trim());
        JSONObject r=postForm(base+"/webapi/entry.cgi", q, null);
        if(r.optBoolean("success")) {
            JSONObject d=r.getJSONObject("data"); sid=d.optString("sid",""); token=d.optString("synotoken","");
            String newDid=d.optString("did",""); if(!newDid.isBlank()){ did=newDid; CryptoStore.put(ctx,"did",did); }
            ctx.getSharedPreferences("cfg",Context.MODE_PRIVATE).edit().putString("sid",sid).putString("token",token).apply();
        }
        return r;
    }

    private void ensureAuth() throws Exception {
        if(sid==null || sid.isBlank()) {
            JSONObject lr=login(null,false); if(!lr.optBoolean("success")) throw new IOException("Necesita volver a iniciar sesión");
        }
    }

    public List<EventItem> events(long startSec, long endSec) throws Exception {
        ensureAuth();
        try { return eventsOnce(startSec,endSec); }
        catch(AuthException ex) { reloginOrThrow(); return eventsOnce(startSec,endSec); }
    }

    private List<EventItem> eventsOnce(long startSec,long endSec) throws Exception {
        Map<String,CalendarInfo> calendars=calendarMapOnce();
        Map<String,String> p=baseParams("SYNO.Cal.Event","5","list");
        p.put("start",Long.toString(startSec)); p.put("end",Long.toString(endSec)); p.put("limit","500");
        JSONObject r=call(p);
        JSONArray list=r.getJSONObject("data").optJSONArray("list"); List<EventItem> out=new ArrayList<>();
        if(list!=null) for(int i=0;i<list.length();i++){
            JSONObject e=list.getJSONObject(i); long st=e.optLong("dtstart",0);
            if(st>0) out.add(parseEvent(e,calendars));
        }
        out.sort(Comparator.comparingLong((EventItem x)->x.start).thenComparingLong(x->x.evtId)); return out;
    }

    public List<CalendarInfo> calendars() throws Exception {
        ensureAuth();
        try { return new ArrayList<>(calendarMapOnce().values()); }
        catch(AuthException ex) { reloginOrThrow(); return new ArrayList<>(calendarMapOnce().values()); }
    }

    private Map<String,CalendarInfo> calendarMapOnce() throws Exception {
        Map<String,String> p=baseParams("SYNO.Cal.Cal","5","list"); p.put("cal_type","event");
        JSONObject r=call(p); JSONArray a=r.getJSONObject("data").optJSONArray("list");
        LinkedHashMap<String,CalendarInfo> out=new LinkedHashMap<>();
        if(a!=null) for(int i=0;i<a.length();i++){
            JSONObject c=a.optJSONObject(i); if(c==null) continue;
            String id=c.optString("cal_id",""); String orig=c.optString("original_cal_id",id);
            String privilege=c.optString("cal_privilege","RW");
            CalendarInfo info=new CalendarInfo(id,orig,c.optString("cal_displayname","Calendario"),
                    c.optString("cal_color",""),!"RO".equalsIgnoreCase(privilege),c.optBoolean("default_calendar",false));
            out.put(id,info);
        }
        return out;
    }

    public JSONObject getEvent(long evtId,String recurrenceId) throws Exception {
        ensureAuth();
        try { return getEventOnce(evtId,recurrenceId); }
        catch(AuthException ex){ reloginOrThrow(); return getEventOnce(evtId,recurrenceId); }
    }
    private JSONObject getEventOnce(long evtId,String recurrenceId)throws Exception{
        Map<String,String> p=baseParams("SYNO.Cal.Event","5","get"); p.put("evt_id",Long.toString(evtId));
        if(recurrenceId!=null&&!recurrenceId.isBlank())p.put("recurrence_id",recurrenceId);
        JSONObject r=call(p); return r.getJSONObject("data");
    }

    public JSONObject updateEvent(long evtId,String recurrenceId,String summary,boolean allDay,long start,long end,String description,String location) throws Exception {
        if(summary==null || summary.trim().isEmpty()) throw new IllegalArgumentException("El título no puede estar vacío");
        if(end<=start) throw new IllegalArgumentException("La hora/fecha de fin debe ser posterior al inicio");

        JSONObject current=getEvent(evtId,recurrenceId);
        String method=(recurrenceId!=null&&!recurrenceId.isBlank())?"subevent_set":"set";
        Map<String,String> p=buildUpdateParams(current,evtId,recurrenceId,method,summary,allDay,start,end,description,location);

        ensureAuth();
        try {
            return call(p);
        } catch(AuthException ex) {
            reloginOrThrow();
            current=getEvent(evtId,recurrenceId);
            p=buildUpdateParams(current,evtId,recurrenceId,method,summary,allDay,start,end,description,location);
            return call(p);
        }
    }

    private Map<String,String> buildUpdateParams(JSONObject current,long evtId,String recurrenceId,String method,
                                                  String summary,boolean allDay,long start,long end,
                                                  String description,String location) {
        Map<String,String> p=baseParams("SYNO.Cal.Event","5",method);
        p.put("evt_id",Long.toString(evtId));
        if("subevent_set".equals(method)) p.put("recurrence_id",recurrenceId);

        String originalCalId=current.optString("original_cal_id","").trim();
        String calId=current.optString("cal_id","").trim();
        // SYNO.Cal.Event.get omite cal_id en algunas versiones de Calendar. En ese caso
        // original_cal_id identifica el calendario real (p. ej. /sergio/home/) y es el
        // valor correcto que debemos conservar para la actualización.
        if(calId.isBlank()) calId=originalCalId;
        if(originalCalId.isBlank()) originalCalId=calId;
        String etag=current.optString("dav_etag","").trim();
        if(calId.isBlank() || originalCalId.isBlank() || etag.isBlank())
            throw new IllegalArgumentException("Synology no ha devuelto los identificadores necesarios del evento. Actualiza la agenda y vuelve a intentarlo.");

        p.put("cal_id",calId);
        p.put("original_cal_id",originalCalId);
        p.put("dav_etag",etag);
        p.put("summary",summary.trim());
        p.put("is_all_day",Boolean.toString(allDay));

        String tz=current.optString("tz_id","");
        if(!allDay && tz.isBlank()) tz=TimeZone.getDefault().getID();
        p.put("tz_id",tz);

        p.put("dtstart",Long.toString(start));
        p.put("dtend",Long.toString(end));
        p.put("color",current.optString("color",""));
        p.put("notify_setting",arrayString(current,"notify_setting"));
        p.put("description",description==null?"":description);

        JSONObject li=current.optJSONObject("location_info");
        if(li==null) li=emptyLocation();
        else {
            try { li=new JSONObject(li.toString()); } catch(Exception ignored) { li=emptyLocation(); }
        }
        String loc=location==null?"":location.trim();
        try {
            li.put("name",loc);
            li.put("address",loc);
            if(!li.has("gps") || li.optJSONObject("gps")==null)
                li.put("gps",new JSONObject().put("lat",-1).put("lng",-1));
            if(!li.has("map_type")) li.put("map_type","");
            if(!li.has("place_id")) li.put("place_id","");
        } catch(Exception ignored) {}
        p.put("location_info",li.toString());
        p.put("attachments",arrayString(current,"attachments"));

        if("set".equals(method)) {
            boolean repeat=current.optBoolean("is_repeat_evt",false);
            p.put("is_repeat_evt",Boolean.toString(repeat));
            if(repeat && current.optJSONObject("repeat_setting")!=null)
                p.put("repeat_setting",current.optJSONObject("repeat_setting").toString());
            p.put("participant",arrayString(current,"participant"));
            if(repeat) {
                String exdate=current.optString("exdate","");
                if(!exdate.isBlank()) p.put("exdate",exdate);
            }
        }
        return p;
    }

    private static EventItem parseEvent(JSONObject e,Map<String,CalendarInfo> calendars){
        String cid=e.optString("cal_id",""); CalendarInfo ci=calendars.get(cid);
        return new EventItem(e.optLong("evt_id",0),e.optString("recurrence_id",""),e.optString("summary","(Sin título)"),
                e.optLong("dtstart",0),e.optLong("dtend",e.optLong("dtstart",0)),e.optBoolean("is_all_day",false),
                cid,e.optString("original_cal_id",cid),e.optString("dav_etag",""),
                ci==null?"":ci.name,ci==null?"":ci.color);
    }
    private static JSONObject emptyLocation(){ try{return new JSONObject().put("address","").put("name","").put("map_type","").put("place_id","").put("gps",new JSONObject().put("lat",-1).put("lng",-1));}catch(Exception e){return new JSONObject();} }
    private static String arrayString(JSONObject o,String k){JSONArray a=o.optJSONArray(k);return a==null?"[]":a.toString();}
    private static String objectOrNullString(JSONObject o,String k){JSONObject x=o.optJSONObject(k);return x==null?"null":x.toString();}

    private Map<String,String> baseParams(String api,String version,String method){ Map<String,String> p=new LinkedHashMap<>(); p.put("api",api);p.put("version",version);p.put("method",method); if(sid!=null&&!sid.isBlank())p.put("_sid",sid);if(token!=null&&!token.isBlank())p.put("SynoToken",token);return p; }
    private JSONObject call(Map<String,String> p)throws Exception{JSONObject r=postForm(base+"/webapi/entry.cgi",p,token);if(!r.optBoolean("success")){int code=r.optJSONObject("error")!=null?r.optJSONObject("error").optInt("code",0):0;if(code==105||code==106||code==107)throw new AuthException();throw new IOException("Synology API error "+code);}return r;}
    private void reloginOrThrow()throws Exception{JSONObject lr=login(null,false);if(!lr.optBoolean("success"))throw new IOException("Sesión caducada: abre Configuración para autenticarte de nuevo");}
    private static class AuthException extends Exception {}
    private static String encode(Map<String,String> map) throws Exception { StringBuilder sb=new StringBuilder(); for(Map.Entry<String,String>e:map.entrySet()){ if(sb.length()>0)sb.append('&'); sb.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(e.getValue(),"UTF-8")); } return sb.toString(); }
    private static JSONObject postForm(String url,Map<String,String> params,String token) throws Exception { byte[] body=encode(params).getBytes(StandardCharsets.UTF_8); HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8"); c.setRequestProperty("Accept","application/json"); if(token!=null&&!token.isBlank()) c.setRequestProperty("X-SYNO-TOKEN",token); try(OutputStream os=c.getOutputStream()){os.write(body);} return read(c); }
    private static JSONObject read(HttpURLConnection c) throws Exception { int code=c.getResponseCode(); InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream(); if(in==null) throw new IOException("HTTP "+code); String text; try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){ StringBuilder sb=new StringBuilder(); String l; while((l=br.readLine())!=null)sb.append(l); text=sb.toString(); } try{return new JSONObject(text);}catch(Exception e){throw new IOException("Respuesta no válida del NAS (HTTP "+code+")");} }
}
